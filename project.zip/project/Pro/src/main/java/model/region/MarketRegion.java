//package model.region;
//
//import model.game.GameMap;
//import model.game.Position;
//import model.game.Region;
//
//public class MarketRegion extends Region {
//    private GameMap marketMap;
//
//    public MarketRegion(String regionName, Position topLeft, int width, int height) {
//        super(regionName, topLeft, width, height);
//        this.marketMap = new GameMap(width, height);
//        initializeMarket();
//    }
//
//    private void initializeMarket() {
//    }
//
//    @Override
//    public void printRegion() {
//
//    }
//
//    public GameMap getMarketMap() {
//        return marketMap;
//    }
//}
