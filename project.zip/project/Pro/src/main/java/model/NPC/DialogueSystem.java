package model.NPC;

import model.Weather.DateAndTime;
import model.Weather.Weather;

public class DialogueSystem {
    public static String getDialogue(NPC npc, DateAndTime time, Weather weather, int friendshipLevel) {
       return "will be done";
    }
}

