package model.NPC;

import model.Player.Player;

public class Gift {
    private String itemName;
    private int amount;
    private int rating;
    private Player sender;
    private Player receiver;

    public Gift(String itemName, int amount) {
        this.itemName = itemName;
        this.amount = amount;
        this.rating = 0;
    }

    public String getItemName() {
        return itemName;
    }

    public void setItemName(String itemName) {
        this.itemName = itemName;
    }

    public int getAmount() {
        return amount;
    }

    public void setAmount(int amount) {
        this.amount = amount;
    }

    public int getRating() {
        return rating;
    }

    public void setRating(int rating) {
        this.rating = rating;
    }

    public Player getSender() {
        return sender;
    }

    public void setSender(Player sender) {
        this.sender = sender;
    }

    public Player getReceiver() {
        return receiver;
    }

    public void setReceiver(Player receiver) {
        this.receiver = receiver;
    }

    public void rateGift(int rating) {
        this.rating = rating;
        adjustFriendshipXp();
    }

    private void adjustFriendshipXp() {
        int xpChange = 15 + 30 * (3 - rating);
    }
}
