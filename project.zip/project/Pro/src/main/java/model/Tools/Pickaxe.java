package model.Tools;

import model.game.Tile;
import model.Player.Player;
import model.enums.PickaxeType;

public class Pickaxe extends Tool {
    private PickaxeType type;

    public Pickaxe(PickaxeType type) {
        super(type.getName(), type.getDisplayChar(), type.getLevel(), type.getBaseEnergyCost());
        this.type = type;
    }

    @Override
    public boolean use(Player player, Tile tile) {
        int energyCost = type.getBaseEnergyCost();
        if (player.getMiningLevel() == Player.MAX_MINING_LEVEL) {
            energyCost = Math.max(0, energyCost - 1);
        }
        if (player.getEnergy() < energyCost) return false;

        boolean success = false;

        if (tile.hasRockOrOre()) {
            if (tile.getRockLevel() <= this.level + 1) {
                tile.breakRock();
                success = true;
            }
        } else if (tile.isTilled()) {
            tile.setTilled(false); // از بین بردن اثر بیل
            success = true;
        } else if (tile.hasDroppedItem()) {
            tile.removeDroppedItem(); // حذف آیتم روی زمین
            success = true;
        }

        // انرژی در هر صورت کم می‌شود، ولی اگر موفق نبود ۱ واحد کمتر
        if (success) {
            player.reduceEnergy(energyCost);
        } else {
            player.reduceEnergy(Math.max(0, energyCost - 1));
        }

        return success;


    }

    @Override
    public boolean canUseOn(Tile tile) {
        return tile.hasRockOrOre() || tile.isTilled() || tile.hasDroppedItem();
    }

    @Override
    public Tool upgrade() {
        return this;
    }

    @Override
    public void interact() {

    }

    @Override
    public int getSellPrice() {
        return 0;
    }
}

