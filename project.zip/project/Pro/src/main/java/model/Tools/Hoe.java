package model.Tools;

import model.Player.Player;
import model.enums.AxeType;
import model.enums.HoeType;
import model.game.Tile;


public class Hoe extends Tool {
    private HoeType type;
    public Hoe(HoeType type) {
        super(type.getName(),type.getDisplayChar(), type.getLevel(), type.getBaseEnergyCost());
        this.type = type;
    }


    @Override
    public boolean use(Player player, Tile tile) {
        int energyCost = type.getBaseEnergyCost();
        if (player.getFarmingLevel() == Player.MAX_FARMING_LEVEL) {
            energyCost = Math.max(0, energyCost - 1);
        }
        if (player.getEnergy() < energyCost) return false;

        if (!canUseOn(tile)) {
            player.reduceEnergy(energyCost);
            return false;
        }

        tile.till();// متد شخم زدن و زمین را اماده کشت کردن
        player.reduceEnergy(energyCost);
        return true;

    }

    @Override
    public boolean canUseOn(Tile tile) {
        return tile.isTillable();
    }

    @Override
    public Tool upgrade() {
        return new Hoe(level + 1);
    }


    @Override
    public void interact() {

    }

    @Override
    public int getSellPrice() {
        return 0;
    }
}

