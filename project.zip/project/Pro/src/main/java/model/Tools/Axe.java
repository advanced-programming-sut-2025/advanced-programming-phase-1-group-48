package model.Tools;


import model.Player.Player;
import model.game.Tile;
import model.enums.AxeType;

public class Axe extends Tool {
    private AxeType type;

    public Axe(AxeType type) {
        super(type.getName(),type.getDisplayChar(), type.getLevel(), type.getBaseEnergyCost());
        this.type = type;
    }

    @Override
    public boolean use(Player player, Tile targetTile) {
        if (!canUseOn(targetTile)) return false;
        int energyCost = type.getBaseEnergyCost();
        if (player.getForginLevel() == Player.MAX_FORAGIN_LEVEL) {
            energyCost = Math.max(0, energyCost - 1);
        }

        if (player.getEnergy() < energyCost) return false;

        player.decreaseEnergy(energyCost);

        if (targetTile.hasTree()) {
            player.getInventory().addItem(model.items.ItemFactory.createItem("Wood",player.getInventory()));
            //شرط اینکه درخت عصاره دارد یا خیر رو بررسی کن
            player.getInventory().addItem(model.items.ItemFactory.createItem("TreeSap",player.getInventory()));
            targetTile.removeTree();
        } else if (targetTile.hasBranch()) {
            targetTile.removeBranch();
        }

        return true;
    }

    @Override
    public boolean canUseOn(Tile tile) {
        return tile.hasTree() || tile.hasBranch();
    }

    @Override
    public Tool upgrade() {
        return null;
    }

    @Override
    public void interact() {
    }

    @Override
    public int getSellPrice() {
        return 0;
    }
}

