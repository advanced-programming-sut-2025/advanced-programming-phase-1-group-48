package model.Tools;


import model.game.Tile;
import model.Player.Player;
import model.enums.WateringCanType;

public class WateringCan extends Tool {
    private WateringCanType type;
    private int currentWater;

    public WateringCan(WateringCanType type) {
        super(type.getName(), type.getLevel(), type.getBaseEnergyCost());
        this.type = type;
        this.currentWater = type.getCapacity();
    }

    public boolean fillFrom(Tile tile) {
        return false;
    }

    @Override
    public boolean use(Player player, Tile targetTile) {
        return false;
    }

    @Override
    public boolean canUseOn(Tile tile) {
        return false;
    }

    @Override
    public Tool upgrade() {
        return null;
    }

    public int getCurrentWater() {
        return currentWater;
    }

    public void refill() {
        this.currentWater = type.getCapacity();
    }

    public WateringCanType getType() {
        return type;
    }
}
