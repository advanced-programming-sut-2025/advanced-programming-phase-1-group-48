package model.Tools;


import model.Animal.Fish;
import model.Player.Player;
import model.game.Tile;
import model.enums.FishingPoleType;

public class FishingPole extends Tool {
    private FishingPoleType type;

    public FishingPole(FishingPoleType type) {
        super(type.getName(), type.getLevel(), type.getBaseEnergyCost());
        this.type = type;
    }

    @Override
    public boolean use(Player player, Tile targetTile) {
        return false;
    }

    @Override
    public boolean canUseOn(Tile tile) {
        return false;
    }

    @Override
    public Tool upgrade() {
        return null;
    }

    public FishingPoleType getType() {
        return type;
    }

    public boolean canCatchFishType(Fish fish) {
        return type.canCatchAllFish();
    }
}
