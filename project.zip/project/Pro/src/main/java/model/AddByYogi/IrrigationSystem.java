package model.AddByYogi;

import model.game.GameMap;
import model.game.Tile;

public class IrrigationSystem {
    /*
     * `increaseGrowth()`.
     */
    public static void autoIrrigate() {
        GameMap map = GameMap.getInstance();
        for (int x = 0; x < map.getWidth(); x++) {
            for (int y = 0; y < map.getHeight(); y++) {
                Tile tile = map.getTile(x, y);
                if (tile.hasCrop()) {
                    tile.getCrop().water();
                }
            }
        }
        System.out.println("IrrigationSystem: automatic watering applied.");
    }
}
