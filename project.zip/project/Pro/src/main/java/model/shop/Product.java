package model.shop;

import java.util.HashMap;
import java.util.Map;

public class Product {
    private final String name;
    private final int price;
    private final int stockLimitPerDay;
    private final Map<String, Integer> requiredIngredients;
    private int remainingToday;

    public Product(String name, int price, int stockLimitPerDay) {
        this(name, price, stockLimitPerDay, Map.of());
    }
    public Product(String name, int price, int stockLimitPerDay, Map<String, Integer> requiredIngredients) {
        this.name = name;
        this.price = price;
        this.stockLimitPerDay = stockLimitPerDay;
        this.requiredIngredients = requiredIngredients;
        this.remainingToday = stockLimitPerDay;
    }

    public Product(Product other) {
        this.name = other.name;
        this.price = other.price;
        this.stockLimitPerDay = other.stockLimitPerDay;
        this.requiredIngredients = other.requiredIngredients; // فرض بر این که immutable یا فقط خواندنیه
        this.remainingToday = other.stockLimitPerDay;
    }


    public boolean isAvailable() {
        return remainingToday > 0;
    }

    public boolean purchase(int quantity) {
        if (quantity <= remainingToday) {
            remainingToday -= quantity;
            return true;
        }
        return false;
    }

    public void resetDaily() {
        remainingToday = stockLimitPerDay;
    }


    public String getName() {
        return name;
    }

    public int getPrice() {
        return price;
    }

    public int getStockLimitPerDay() {
        return stockLimitPerDay;
    }

    public int getRemainingToday() {
        return remainingToday;
    }

    public Map<String, Integer> getRequiredIngredients() {
        return requiredIngredients;
    }
}
