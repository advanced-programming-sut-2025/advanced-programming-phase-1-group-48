package model.Weather;

import model.enums.Season;
import model.enums.WeatherType;
import model.AddByYogi.IrrigationSystem;

import static model.enums.Season.*;


public class Effect {


    public static void apply(String currentSeasonName) {
        Season season = Season.valueOf(currentSeasonName);
        WeatherType weather = Weather.getInstance().getToday();

        switch (weather) {
            case Sunny:
                applySunny(season);
                break;
            case Rain:
                applyRain(season);
                break;
            case Storm:
                applyStorm(season);
                break;
            case Snow:
                applySnow(season);
                break;
        }

        System.out.printf("Applied weather effects: season=%s, weather=%s%n", season, weather);
    }

    private static void applySunny(Season season) {
        /// ////////////
    }

    private static void applyRain(Season season) {
        if (season == SPRING || season == SUMMER || season == FALL) {
            IrrigationSystem.autoIrrigate();
        }
       /// /////////
        Thunderbolt.getInstance().strikeRain();
    }

    private static void applyStorm(Season season) {
        applyRain(season);
        Thunderbolt.getInstance().strikeStorm();
    }

    private static void applySnow(Season season) {
        if (season == WINTER) {
            /// //////////////
        } else {
            /// //////////////////////
        }
    }

}
