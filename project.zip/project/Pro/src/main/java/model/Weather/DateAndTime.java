package model.Weather;


import model.enums.Season;
import model.shop.ShopManager;
import controllers.Game;
import model.Player.Player;

public class DateAndTime {
    private static DateAndTime instance;
    private static int totalDays = 0;
    private static final String[] WEEK_DAYS = {
            "Saturday", "Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday"
    };



    private static int hour = 9;
    private static int day = 1;
    private static int year =0;
    private static final int DAYS_PER_SEASON = 28;
    public static Season currentSeason = Season.SPRING;

    private DateAndTime() {}

    public static Season getSeasonType() {
        return instance.currentSeason;
    }

    public static DateAndTime getInstance() {
        if (instance == null) {
            instance = new DateAndTime();
        }
        return instance;
    }

    public static  void advanceHour(int hours) {
        hour += hours;
        while (hour >= 22) {
            hour = 9;
            advanceDay(1);
            startDay();


        }
    }
    public static void startDay() {
        Player player= Game.getCurrentPlayer();
        player.resetDailyEnergy();
        shopManager.resetDailyStock();
    }
    public static void advanceDay(int days) {
        day+=days;
        totalDays+=days;
        Weather.getInstance().advanceDayAndWeather();
        if (day > DAYS_PER_SEASON) {
            day = 1;
            nextSeason();
        }
    }

    public static Season getCurrentSeason() {
        return currentSeason;
    }

    public static void displayDayOfWeek() {
        int idx = totalDays % WEEK_DAYS.length;
        System.out.printf("Day of week: %s%n", WEEK_DAYS[idx]);
    }

    public void displayDate() {
        System.out.printf("Current date: Year %d, Day %d of %s%n", year, day, currentSeason);
    }

    public static int getTotalDays() {
        return totalDays;
    }

    public static int getHour() {
        return hour;
    }

    public static int getDay() {
        return day;
    }

    private static void nextSeason() {
        int idx = currentSeason.ordinal();
        Season[] seasons = Season.values();
        currentSeason = seasons[(idx + 1) % seasons.length];
        if (currentSeason == Season.SPRING) {
            year++;
        }
    }
}
