package model.Weather;

import model.game.GameMap;
import model.game.Tile;
import java.util.Random;

public class Thunderbolt {
    private static Thunderbolt instance;

    private Thunderbolt() {}

    public static synchronized Thunderbolt getInstance() {
        if (instance == null) {
            instance = new Thunderbolt();
        }
        return instance;
    }

    public void strikeAt(int x, int y) {
        GameMap map = GameMap.getInstance();
        if (x < 0 || x >= map.getWidth() || y < 0 || y >= map.getHeight()) {
            System.err.printf("Error: Coordinates (%d,%d) out of bounds.%n", x, y);
            return;
        }
        Tile tile = map.getTile(x, y);
        if (tile.hasTree()) {
            tile.removeTree();
            System.out.printf("A tree at (%d,%d) was struck by lightning!%n", x, y);
        }
        if (tile.hasCrop()) {
            tile.getCrop().kill();
            System.out.printf("A crop at (%d,%d) was destroyed by lightning!%n", x, y);
        }
    }


    public void strikeStorm() {
        Random rand = new Random();
        GameMap map = GameMap.getInstance();
        int width = map.getWidth();
        int height = map.getHeight();
        for (int i = 0; i < 3; i++) {
            int x = rand.nextInt(width);
            int y = rand.nextInt(height);
            strikeAt(x, y);
        }
    }

    public static void handleCheatCommand(String input) {
        String[] tokens = input.trim().split("\\s+");
        if (tokens.length >= 4
                && tokens[0].equalsIgnoreCase("cheat")
                && tokens[1].equalsIgnoreCase("Thor")
                && tokens[2].equalsIgnoreCase("-l")) {
            try {
                String[] xy = tokens[3].split(",");
                int x = Integer.parseInt(xy[0]);
                int y = Integer.parseInt(xy[1]);
                getInstance().strikeAt(x, y);
            } catch (Exception e) {
                System.err.println("Error: invalid coordinates for cheat Thor -l <x,y>");
            }
        }
    }
}
