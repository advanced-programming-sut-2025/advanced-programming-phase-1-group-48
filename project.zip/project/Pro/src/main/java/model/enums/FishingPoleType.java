package model.enums;


public enum FishingPoleType {
    TRAINING("Training Rod", 0, 8, false),
    BAMBOO("Bamboo Rod", 1, 8, true),
    FIBERGLASS("Fiberglass Rod", 2, 6, true),
    IRIDIUM("Iridium Rod", 3, 4, true);

    private final String name;
    private final int level;
    private final int baseEnergyCost;
    private final boolean canCatchAllFish;

    FishingPoleType(String name, int level, int baseEnergyCost, boolean canCatchAllFish) {
        this.name = name;
        this.level = level;
        this.baseEnergyCost = baseEnergyCost;
        this.canCatchAllFish = canCatchAllFish;
    }

    public String getName() { return name; }
    public int getLevel() { return level; }
    public int getBaseEnergyCost() { return baseEnergyCost; }
    public boolean canCatchAllFish() { return canCatchAllFish; }
}

