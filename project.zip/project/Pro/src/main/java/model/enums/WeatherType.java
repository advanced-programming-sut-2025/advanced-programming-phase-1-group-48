package model.enums;

import java.util.EnumSet;
import java.util.Set;


public enum WeatherType {
    Sunny(EnumSet.of(Season.Spring, Season.Summer, Season.Fall, Season.Winter)),
    Rain(EnumSet.of(Season.Spring, Season.Summer, Season.Fall)),
    Storm(EnumSet.of(Season.Spring, Season.Summer, Season.Fall)),
    Snow(EnumSet.of(Season.Winter));

    // فصل(های) مجاز برای این WeatherType
    private final Set<Season> validSeasons;

    WeatherType(Set<Season> validSeasons) {
        this.validSeasons = validSeasons;
    }

    /**
     * آیا این وضعیت جوی در فصل مشخص شده می‌تواند رخ دهد؟
     */
    public boolean isValidForSeason(Season season) {
        return validSeasons.contains(season);
    }

    /**
     * برمی‌گرداند مجموعه‌ی فصل‌های مجاز
     */
    public Set<Season> getValidSeasons() {
        return EnumSet.copyOf(validSeasons);
    }
}
