package model.enums;

public enum Building {
    COOP,
    BIG_COOP,
    DELUXE_COOP,
    BARN,
    BIG_BARN,
    DELUXE_BARN
}
