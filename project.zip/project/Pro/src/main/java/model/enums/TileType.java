package model.enums;

public enum TileType {
    EMPTY,
    LAKE,
    CABIN,
    GREENHOUSE,
    QUARRY,
    TREE,
    ROCK,
    FORAGING,
    NPC_HOUSE,
    SHOP,
    PATH
}
