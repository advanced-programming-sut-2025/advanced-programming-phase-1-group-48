package model.enums;

public enum Season {
    SPRING,
    SUMMER,
    FALL,
    WINTER,
    SPECIAL;// برای مواردی که فصل مشخص ندارند یا خاص هستند

    /**
     * اگر ورودی از کاربر یا فایل متنی داشتی که با حروف کوچک یا
     * با فاصله (مثلاً "Spring & Summer") آمده، می‌توانی با این متد آن را مپ کنی:
     */
    public static Season fromString(String s) {
        if (s == null) {
            throw new IllegalArgumentException("Season string is null");
        }
        s = s.trim().toLowerCase();
        switch (s) {
            case "spring":           return SPRING;
            case "summer":           return SUMMER;
            case "fall": case "autumn": return FALL;
            case "winter":           return WINTER;
            default:
                // موارد ترکیبی یا خاص
                return SPECIAL;
        }
    }
}
