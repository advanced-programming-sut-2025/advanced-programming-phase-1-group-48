package model.enums;

import model.shop.AnimalProduct;
import model.shop.Product;

import java.time.LocalTime;
import java.util.List;
import java.util.Map;

public enum ShopType {
    BLACKSMITH("Clint", LocalTime.of(9, 0), LocalTime.of(16, 0),
            List.of(
                    new Product("Copper Ore", 75, Integer.MAX_VALUE),
                    new Product("Iron Ore", 150, Integer.MAX_VALUE),
                    new Product("Gold Ore", 400, Integer.MAX_VALUE),
                    new Product("Coal", 150, Integer.MAX_VALUE),

                    new Product("Copper Tool", 2000, 1, Map.of("Copper Bar", 5)),
                    new Product("Steel Tool", 5000, 1, Map.of("Iron Bar", 5)),
                    new Product("Gold Tool", 10000, 1, Map.of("Gold Bar", 5)),
                    new Product("Iridium Tool", 25000, 1, Map.of("Iridium Bar", 5)),

                    new Product("Copper Trash Can", 1000, 1, Map.of("Copper Bar", 5)),
                    new Product("Steel Trash Can", 2500, 1, Map.of("Iron Bar", 5)),
                    new Product("Gold Trash Can", 5000, 1, Map.of("Gold Bar", 5)),
                    new Product("Iridium Trash Can", 12500, 1, Map.of("Iridium Bar", 5))

            )),

    JOJA_MART("Morris", LocalTime.of(9, 0), LocalTime.of(23, 0),
            List.of(
                    // General Goods
                    new Product("Parsnip Seed", 20, 20),
                    new Product("Fertilizer", 100, 10),
                    new Product("Hay", 50, Integer.MAX_VALUE),
                    new Product("Milk Pail", 1000, 1),
                    new Product("Shears", 1000, 1),

                    // Farm Animals
                    new AnimalProduct("Chicken", 800, 2, Building.COOP),
                    new AnimalProduct("Cow", 1500, 2, Building.BARN),
                    new AnimalProduct("Goat", 4000, 2, Building.BIG_BARN),
                    new AnimalProduct("Duck", 1200, 2, Building.BIG_COOP),
                    new AnimalProduct("Sheep", 8000, 2, Building.DELUXE_BARN),
                    new AnimalProduct("Rabbit", 8000, 2, Building.DELUXE_COOP),
                    new AnimalProduct("Dinosaur", 14000, 2, Building.BIG_COOP),
                    new AnimalProduct("Pig", 16000, 2, Building.DELUXE_BARN)

            )),
    PIERRE_STORE("Pierre", LocalTime.of(9, 0), LocalTime.of(17, 0),
    List.of(
            new Product("Parsnip Seeds", 20, 100),
            new Product("Backpack Upgrade", 2000, 2)
        )),
    CARPENTER("Robin", LocalTime.of(9, 0), LocalTime.of(20, 0),
            List.of(
            new Product("Barn Construction", 4000, 1),
            new Product("Wood", 10, 50)
    )),
    FISH_SHOP("Willy", LocalTime.of(9, 0), LocalTime.of(17, 0),
            List.of(
                    new Product("Fishing Rod", 500, 2),
                    new Product("Bait", 50, 100)
            )),
    MARNIE_RANCH("Marnie", LocalTime.of(9, 0), LocalTime.of(16, 0),
            List.of(
                    new Product("Chicken", 800, 2),
                    new Product("Milk Pail", 1000, 1)
            ) ),
    STAR_DROP_SALOON("Gus", LocalTime.of(12, 0), LocalTime.of(0, 0),
            List.of(
                    new Product("Beer", 400, 10),
                    new Product("Spaghetti", 240, 5)
            ));

    private final String ownerName;
    private final LocalTime openTime;
    private final LocalTime closeTime;
    private final List<Product> defaultProducts;

    ShopType(String ownerName, LocalTime open, LocalTime close, List<Product> defaultProducts) {
        this.ownerName = ownerName;
        this.openTime = open;
        this.closeTime = close;
        this.defaultProducts = defaultProducts;
    }

    public String getOwnerName() {
        return ownerName;
    }

    public LocalTime getOpenTime() {
        return openTime;
    }

    public LocalTime getCloseTime() {
        return closeTime;
    }
    public List<Product> getDefaultProducts() {
        return defaultProducts;
    }

}
