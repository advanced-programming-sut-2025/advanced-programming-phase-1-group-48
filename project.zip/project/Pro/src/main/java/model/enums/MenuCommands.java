package model.enums;

import java.util.regex.Pattern;

public enum MenuCommands {
    REGISTER("register\\s+-u\\s+(?<username>.*)\\s+-p\\s+(?<password>.*)\\s+(?<passwordConfirm>.*)\\s+-n\\s+(?<nickname>.*)\\s+-e\\s+" +
            "(?<email>.*)\\s+-g\\s+(?<gender>.*)"),
    PICK_QUESTION("pick\\s+question\\s+-q\\s+(?<questionNumber>.*)\\s+-a\\s+(?<answer>.*)\\s+-c\\s+(?<answerConfirm>.*)"),
    LOGIN("login\\s+-u\\s+(?<username>.*)\\s+-p\\s+(?<password>.*)(?:\\s+-stay-logged-in)?"),
    FORGET_PASSWORD("forget\\s+password\\s+-u\\s+(?<username>.*)");



    private final Pattern pattern;

    MenuCommands(String regex) {
        this.pattern = Pattern.compile(regex, Pattern.CASE_INSENSITIVE);
    }

    public Pattern getPattern() {
        return pattern;
    }
}
