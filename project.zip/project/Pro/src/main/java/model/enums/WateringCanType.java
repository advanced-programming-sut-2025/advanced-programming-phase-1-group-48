package model.enums;

public enum WateringCanType {
    BASIC("Basic Watering Can", 'B', 0, 40, 5),
    COPPER("Copper Watering Can", 'C', 1, 55, 4),
    IRON("Iron Watering Can", 'I', 2, 70, 3),
    GOLD("Gold Watering Can", 'G', 3, 85, 2),
    IRIDIUM("Iridium Watering Can", 'D', 4, 100, 1);

    private final String name;
    private final char displayChar;
    private final int level;
    private final int capacity;
    private final int baseEnergyCost;

    WateringCanType(String name, char displayChar, int level, int capacity, int baseEnergyCost) {
        this.name = name;
        this.displayChar = displayChar;
        this.level = level;
        this.capacity = capacity;
        this.baseEnergyCost = baseEnergyCost;
    }

    public String getName() { return name; }
    public char getDisplayChar() { return displayChar; }
    public int getLevel() { return level; }
    public int getCapacity() { return capacity; }
    public int getBaseEnergyCost() { return baseEnergyCost; }
}
