package model.Plant;

import model.enums.Season;

public enum TreeType implements Plantable{

    APRICOT_TREE("Apricot Tree","Apricot Sapling",new int[]{7,7,7,7},28,"Apricot",1,59,true,38,Season.SPRING),
    CHERRY_TREE("Cherry Tree","Cherry Sapling",new int[]{7,7,7,7},28,"Cherry",1,80,true,38,Season.SPRING),
    BANANA_TREE("Banana Tree","Banana Sapling",new int[]{7,7,7,7},28,"Banana",1,150,true,75,Season.SUMMER),
    MANGO_TREE("Mango Tree","Mango Sapling",new int[]{7,7,7,7},28,"Mango",1,130,true,100,Season.SUMMER),
    ORANGE_TREE("Orange Tree","Orange Sapling",new int[]{7,7,7,7},28,"Orange",1,100,true,38,Season.SUMMER),
    PEACH_TREE("Peach Tree","Peach Sapling",new int[]{7,7,7,7},28,"Peach",1,140,true,38,Season.SUMMER),
    APPLE_TREE("Apple Tree","Apple Sapling",new int[]{7,7,7,7},28,"Apple",1,100,true,38,Season.FALL),
    POMEGRANATE_TREE("Pomegranate Tree","Pomegranate Sapling",new int[]{7,7,7,7},28,"Pomegranate",1,140,true,38,Season.FALL),
    OAK_TREE("Oak Tree","Acorns",new int[]{7,7,7,7},28,"Oak Resin",7,150,false,-1,Season.SPECIAL),
    MAPLE_TREE("Maple Tree","Maple Seeds",new int[]{7,7,7,7},28,"Maple Syrup",9,200,false,-1,Season.SPECIAL),
    PINE_TREE("Pine Tree","Pine Cones",new int[]{7,7,7,7},28,"Pine Tar",5,100,false,-1,Season.SPECIAL),
    MAHOGANY_TREE("Mahogany Tree","Mahogany Seeds",new int[]{7,7,7,7},28,"Sap",1,2,true,-2,Season.SPECIAL),
    MUSHROOM_TREE("Mushroom Tree","Mushroom Tree Seeds",new int[]{7,7,7,7},28,"Common Mushroom",1,40,true,38,Season.SPECIAL),
    MYSTIC_TREE("Mystic Tree","Mystic Tree Seeds",new int[]{7,7,7,7},28,"Mystic Syrup",7,1000,true,500,Season.SPECIAL);

    private final String name;
    private final String seedSource;
    private final int[] stages;
    private final int totalTime;
    private final String fruit;
    private final int fruitCycle;
    private final int fruitBasePrice;
    private final boolean isEdible;
    private final int fruitEnergy;
    private final Season fruitSeason;


    TreeType(String name, String seedSource, int[] stages, int totalTime, String fruit, int fruitCycle,
             int fruitBasePrice, boolean isEdible, int fruitEnergy, Season fruitSeason) {
        this.name = name;
        this.seedSource = seedSource;
        this.stages = stages;
        this.totalTime = totalTime;
        this.fruit = fruit;
        this.fruitCycle = fruitCycle;
        this.fruitBasePrice = fruitBasePrice;
        this.isEdible = isEdible;
        this.fruitEnergy = fruitEnergy;
        this.fruitSeason= fruitSeason;
    }
    @Override
    public String getName() {
        return name;
    }

    @Override
    public Season getSeason() {
        return fruitSeason;
    }

    @Override
    public int getBaseSellPrice() {
        return fruitBasePrice;
    }

    // اگر Plantable متد isEdible و getEnergyRestored داشت:
    @Override
    public boolean isEdible() {
        return isEdible;
    }

    @Override
    public int getEnergyRestored() {
        return fruitEnergy;
    }

    // منبع (مثلاً seedSource یا "foraging"):
    @Override
    public String getSource() {
        return seedSource;
    }

    // مدت زمان رشد کامل (برای محصولاتی که رشد دارند)
    @Override
    public int getGrowthTime() {
        return totalTime;
    }
    public String getSeedSource() {
        return seedSource;
    }

    public int[] getStages() {
        return stages;
    }

    public int getTotalTime() {
        return totalTime;
    }

    public String getFruit() {
        return fruit;
    }

    public int getFruitCycle() {
        return fruitCycle;
    }

    public int getFruitBasePrice() {
        return fruitBasePrice;
    }

    public int getFruitEnergy() {
        return fruitEnergy;
    }

    public Season getFruitSeason() {
        return fruitSeason;
    }
}
