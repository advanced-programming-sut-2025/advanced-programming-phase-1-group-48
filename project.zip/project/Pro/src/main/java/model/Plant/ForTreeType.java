package model.Plant;

public enum ForTreeType {
    ACORNS("Acorns", "Special"),
    MAPLE_SEEDS("Maple Seeds", "Special"),
    PINE_CONES("Pine Cones", "Special"),
    MAHOGANY_SEEDS("Mahogany Seeds", "Special"),
    MUSHROOM_TREE_SEEDS("Mushroom Tree Seeds", "Special");

    private final String displayName;
    private final String category;

    ForTreeType(String displayName, String category) {
        this.displayName = displayName;
        this.category = category;
    }

    /** نام قابل نمایش آیتم */
    public String getDisplayName() {
        return displayName;
    }

    /** دسته‌بندی آیتم (اینجا همه \"Special\") */
    public String getCategory() {
        return category;
    }
}
