package model.Plant;

public class Mineral {
    private String name;
    private int price;

    Mineral(String name, int price) {
        this.name = name;
        this.price = price;
    }

    //TODO

    public String getName() {
        return name;
    }

    public int getPrice() {
        return price;
    }
}
