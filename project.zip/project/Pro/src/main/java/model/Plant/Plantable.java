package model.Plant;

import model.enums.Season;

public interface Plantable {
    String getName();
    Season getSeason();
    int getBaseSellPrice();

    boolean isEdible();
    int getEnergyRestored();

    String getSource();

    int getGrowthTime();
}
