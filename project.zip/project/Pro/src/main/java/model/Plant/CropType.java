package model.Plant;

import model.enums.Season;

public enum CropType implements Plantable {
    BLUE_JAZZ("Blue Jazz", "Jazz Seeds", new  int[]{1-2-2-2}, 7, true, null, 50, true, 45, Season.SPRING, false),
    CARROT("Carrot", "CarrotSeeds", new  int[]{1-1-1}, 3, true, null, 35, true, 75, Season.SPRING, false),
    CAULIFLOWER("Cauliflower", "Cauliflower Seeds", new int[]{1,2,4,4,1}, 12, true, null, 175, true, 75, Season.SPRING, true),
    COFFEE_BEAN("Coffee Bean", "Coffee Bean", new int[]{1,2,2,3,2}, 10, false, 2, 15, false, 0, Season.SPRING, false),
    GARLIC("Garlic", "Garlic Seeds", new int[]{1,1,1,1}, 4, true, null, 60, true, 20, Season.SPRING, false),
    GREEN_BEAN("Green Bean", "Bean Starter", new int[]{1,1,1,3,4}, 10, false, 3, 40, true, 25, Season.SPRING, false),
    KALE("Kale", "Kale Seeds", new int[]{1,2,2,1}, 6, true, null, 110, true, 50, Season.SPRING, false),
    PARSNIP("Parsnip", "Parsnip Seeds", new int[]{1,1,1,1}, 4, true, null, 35, true, 25, Season.SPRING, false),
    POTATO("Potato", "Potato Seeds", new int[]{1,1,1,2,1}, 6, true, null, 80, true, 25, Season.SPRING, false),
    RHUBARB("Rhubarb", "Rhubarb Seeds", new int[]{2,2,2,3,4}, 13, true, null, 220, false, 0, Season.SPRING, false),
    STRAWBERRY("Strawberry", "Strawberry Seeds", new int[]{1,1,2,2,2}, 8, false, 4, 120, true, 50, Season.SPRING, false),
    TULIP("Tulip", "Tulip Bulb", new int[]{1,1,2,2}, 6, true, null, 30, true, 45, Season.SPRING, false),
    UNMILLED_RICE("Unmilled Rice", "Rice Shoot", new int[]{1,2,2,3}, 8, true, null, 30, true, 3, Season.SPRING, false),
    BLUEBERRY("Blueberry", "Blueberry Seeds", new int[]{1,3,3,4,2}, 13, false, 4, 50, true, 25, Season.SUMMER, false),
    CORN("Corn", "Corn Seeds", new int[]{2,3,3,3,3}, 14, false, 4, 50, true, 25, Season.SUMMER, false),
    HOPS("Hops", "Hops Starter", new int[]{1,1,2,3,4}, 11, false, 1, 25, true, 45, Season.SUMMER, false),
    HOT_PEPPER("Hot Pepper", "Pepper Seeds", new int[]{1,1,1,1,1}, 5, false, 3, 40, true, 13, Season.SUMMER, false),
    MELON("Melon", "Melon Seeds", new int[]{1,2,3,3,3}, 12, true, null, 250, true, 113, Season.SUMMER, true),
    POPPY("Poppy", "Poppy Seeds", new int[]{1,2,2,2}, 7, true, null, 140, true, 45, Season.SUMMER, false),
    RADISH("Radish", "Radish Seeds", new int[]{2,1,2,1}, 6, true, null, 90, true, 45, Season.SUMMER, false),
    RED_CABBAGE("Red Cabbage", "Red Cabbage Seeds", new int[]{2,1,2,2,2}, 9, true, null, 260, true, 75, Season.SUMMER, false),
    STARFRUIT("Starfruit", "Starfruit Seeds", new int[]{2,3,2,3,3}, 13, true, null, 750, true, 125, Season.SUMMER, false),
    SUMMER_SPANGLE("Summer Spangle", "Spangle Seeds", new int[]{1,2,3,1}, 8, true, null, 90, true, 45, Season.SUMMER, false),
    SUMMER_SQUASH("Summer Squash", "Summer Squash Seeds", new int[]{1,1,1,2,1}, 6, false, 3, 45, true, 63, Season.SUMMER, false),
    SUNFLOWER("Sunflower", "Sunflower Seeds", new int[]{1,2,3,2}, 8, true, null, 80, true, 45, Season.SUMMER, false),
    TOMATO("Tomato", "Tomato Seeds", new int[]{2,2,2,2,3}, 11, false, 4, 60, true, 20, Season.SUMMER, false),
    WHEAT("Wheat", "Wheat Seeds", new int[]{1,1,1,1}, 4, true, null, 25, false, 0, Season.SUMMER, false),
    AMARANTH("Amaranth", "Amaranth Seeds", new int[]{1,2,2,2}, 7, true, null, 150, true, 50, Season.FALL, false),
    ARTICHOKE("Artichoke", "Artichoke Seeds", new int[]{2,2,1,2,1}, 8, true, null, 160, true, 30, Season.FALL, false),
    BEET("Beet", "Beet Seeds", new int[]{1,1,2,2}, 6, true, null, 100, true, 30, Season.FALL, false),
    BOK_CHOY("Bok Choy", "Bok Choy Seeds", new int[]{1,1,1,1}, 4, true, null, 80, true, 25, Season.FALL, false),
    BROCCOLI("Broccoli", "Broccoli Seeds", new int[]{2,2,2,2}, 8, false, 4, 70, true, 63, Season.FALL, false),
    CRANBERRIES("Cranberries", "Cranberry Seeds", new int[]{1,2,1,1,2}, 7, false, 5, 75, true, 38, Season.FALL, false),
    EGGPLANT("Eggplant", "Eggplant Seeds", new int[]{1,1,1,1}, 5, false, 5, 60, true, 20, Season.FALL, false),
    FAIRY_ROSE("Fairy Rose", "Fairy Seeds", new int[]{1,4,4,3}, 12, true, null, 290, true, 45, Season.FALL, false),
    GRAPE("Grape", "Grape Starter", new int[]{1,1,2,3,3}, 10, false, 3, 80, true, 38, Season.FALL, false),
    PUMPKIN("Pumpkin", "Pumpkin Seeds", new int[]{1,2,3,4,3}, 13, true, null, 320, false, 0, Season.FALL, true),
    YAM("Yam", "Yam Seeds", new int[]{1,3,3,3}, 10, true, null, 160, true, 45, Season.FALL, false),
    SWEET_GEM_BERRY("Sweet Gem Berry", "Rare Seed", new int[]{2,4,6,6,6}, 24, true, null, 3000, false, 0, Season.FALL, false),
    POWDERMELON("Powdermelon", "Powdermelon Seeds", new int[]{1,2,1,2,1}, 7, true, null, 60, true, 63, Season.WINTER, true),
    ANCIENT_FRUIT("Ancient Fruit", "Ancient Seeds", new int[]{2,7,7,7,5}, 28, false, 7, 550, false, 0, Season.SPECIAL, false)

    ;

    private final String name;
    private final String seedSource;// Nullable
    private final int[] stages;
    private final int totalTime;
    private final boolean oneTime;
    private final Integer regrowth;
    private final int baseSell;
    private final boolean edible;
    private final int energy;
    private final Season season;
    private final boolean canGiant;

    CropType(String name,String seedSource, int[] stages,int totalTime,boolean oneTime
    ,Integer regrowth,int baseSell,boolean edible,int energy, Season season, boolean canGiant) {
        this.name       = name;
        this.season     = season;
        this.baseSell   = baseSell;
        this.seedSource = seedSource;
        this.stages     = stages;
        this.totalTime  = totalTime;
        this.oneTime    = oneTime;
        this.regrowth   = regrowth;
        this.edible     = edible;
        this.energy     = energy;
        this.canGiant   = canGiant;
    }

    // اینجا باید همه‌ی getter های Plantable رو پیاده‌سازی کنی:
    @Override
    public String getName() {
        return name;
    }

    @Override
    public Season getSeason() {
        return season;
    }

    @Override
    public int getBaseSellPrice() {
        return baseSell;
    }

    @Override
    public boolean isEdible() {
        return edible;
    }

    @Override
    public int getEnergyRestored() {
        return energy;
    }

    @Override
    public String getSource() {
        return seedSource;
    }

    @Override
    public int getGrowthTime() {
        return totalTime;
    }


}
