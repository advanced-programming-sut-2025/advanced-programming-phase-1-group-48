package model.Plant;


import model.enums.Season;

import java.util.List;

public enum MixSeedType implements SeedProvider<CropType> {
    SPRING_MIX("Spring Mixed Seeds", Season.SPRING,
            List.of(
                    CropType.CAULIFLOWER,
                    CropType.PARSNIP,
                    CropType.POTATO,
                    CropType.BLUE_JAZZ,
                    CropType.TULIP
            )),

    SUMMER_MIX("Summer Mixed Seeds", Season.SUMMER,
            List.of(
                    CropType.CORN,
                    CropType.HOT_PEPPER,
                    CropType.RADISH,
                    CropType.WHEAT,
                    CropType.POPPY,
                    CropType.SUNFLOWER,
                    CropType.SUMMER_SPANGLE
            )),

    FALL_MIX("Fall Mixed Seeds", Season.FALL,
            List.of(
                    CropType.ARTICHOKE,
                    CropType.CORN,
                    CropType.EGGPLANT,
                    CropType.PUMPKIN,
                    CropType.SUNFLOWER,
                    CropType.FAIRY_ROSE
            )),

    WINTER_MIX("Winter Mixed Seeds", Season.WINTER,
            List.of(
                    CropType.POWDERMELON
            ));


    private final String name;
    private final Season season;
    private final List<CropType> possibleCrops;

    MixSeedType(String name, Season season, List<CropType> possibleCrops) {
        this.name = name;
        this.season = season;
        this.possibleCrops = possibleCrops;
    }

    @Override
    public String getName() {
        return name;
    }

    @Override
    public Season getSeason() {
        return season;
    }

    @Override
    public List<CropType> getPossiblePlants() {
        return possibleCrops;
    }
}

