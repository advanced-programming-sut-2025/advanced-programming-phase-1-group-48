package model.Animal;

import java.util.HashMap;

public enum AnimalProduct {
    EGG("egg",1,100),
    LARGE_EGG("large egg",1,100),
    DUCK_EGG("duck egg",2,100),
    DUCK_FEATHER("duck feather",2,100),
    RABBITE_WOOL("rabbite wool",4,100),
    RABBIT_FOOT("rabbit foot",4,100),
    DINOSAUR_EGG("dinosaur egg",7,100),
    MILK("milk",1,100),
    LARGE_MILK("large milk",1,100),
    GOAT_MILK("goat milk",2,100),
    LARGE_GOATMILK("large goat milk",2,100),
    SHEEP_WOOL("sheep wool",3,100),
    TRUFFLE("truffle",1,100),
    ;
    private String name;
    private int productTime;
    private int productQuality;

    AnimalProduct( String name,int productTime, int productQuality) {

        this.productTime = productTime;

    }

    //TODO

}
