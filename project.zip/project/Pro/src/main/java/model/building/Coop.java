package model.building;

import model.game.Position;

public class Coop extends Buildings{

    public Coop(String name, Position topLeft, int width, int height) {
        super(name, topLeft, width, height);
    }

    @Override
    public void interact() {

    }
}
