package model.building.npcHomes;

import model.game.Position;

public class HarveyHome extends NpcHouse {
    public HarveyHome(String name, String npcName, Position topLeft, int width, int height) {
        super(name, npcName, topLeft, width, height);
    }
}
