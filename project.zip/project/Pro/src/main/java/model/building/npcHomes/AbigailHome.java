package model.building.npcHomes;

import model.game.Position;

public class AbigailHome extends NpcHouse {
    public AbigailHome(String name, String npcName, Position topLeft, int width, int height) {
        super(name, npcName, topLeft, width, height);
    }
}
