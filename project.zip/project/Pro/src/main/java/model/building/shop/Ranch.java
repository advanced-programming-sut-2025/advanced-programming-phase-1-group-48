package model.building.shop;

import model.game.Position;
import model.enums.ShopType;
import java.time.LocalTime;

public class Ranch extends ShopBuilding {
    public Ranch(Position pos) {
        super("Ranch", pos, 5, 5, LocalTime.of(9, 0), LocalTime.of(16, 0), "Marnie");
    }

    @Override
    public ShopType getShopType() {
        return ShopType.RANCH;
    }
}
