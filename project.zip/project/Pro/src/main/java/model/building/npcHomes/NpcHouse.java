package model.building.npcHomes;

import model.building.Buildings;
import model.game.Position;

public class NpcHouse extends Buildings {
    protected String npcName;

    public NpcHouse(String name, String npcName, Position topLeft, int width, int height) {
        super(name, topLeft, width, height);
        this.npcName = npcName;
    }

    @Override
    public void interact() {
    }
}
