package model.building;

public class Greenhouse {
    boolean isBuilt;
    void tryToBuild(int wood, int gold){};

    boolean hasWaterTank(){
        return false;
    }
    void refillWateringCan(){}

}
