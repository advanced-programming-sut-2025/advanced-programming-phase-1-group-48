package model.building;

import model.game.Position;

public class Barn extends Buildings {

    public Barn(String name, Position topLeft, int width, int height) {
        super(name, topLeft, width, height);
    }

    public void creatBarn(){}

    @Override
    public void interact() {

    }
}
