package model.building.shop;


import model.game.Position;
import model.enums.ShopType;
import java.time.LocalTime;

public class BlacksmithShop extends ShopBuilding {
    public BlacksmithShop(Position pos) {
        super("Blacksmith", pos, 5, 5, LocalTime.of(9, 0), LocalTime.of(16, 0), "Clint");
    }

    @Override
    public ShopType getShopType() {
        return ShopType.BLACKSMITH;
    }
}
