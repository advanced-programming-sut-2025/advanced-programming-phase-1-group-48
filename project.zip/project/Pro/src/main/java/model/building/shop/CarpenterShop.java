package model.building.shop;

import model.game.Position;
import model.enums.ShopType;
import java.time.LocalTime;

public class CarpenterShop extends ShopBuilding {
    public CarpenterShop(Position pos) {
        super("Carpenter Shop", pos, 5, 5, LocalTime.of(9, 0), LocalTime.of(20, 0), "Robin");
    }

    @Override
    public ShopType getShopType() {
        return ShopType.CARPENTER;
    }
}
