package model.building.shop;

import model.game.Position;
import model.enums.ShopType;
import java.time.LocalTime;

public class Saloon extends ShopBuilding {
    public Saloon(Position pos) {
        super("Stardrop Saloon", pos, 6, 5, LocalTime.of(12, 0), LocalTime.of(23, 59), "Gus");
    }

    @Override
    public ShopType getShopType() {
        return ShopType.SALOON;
    }
}
