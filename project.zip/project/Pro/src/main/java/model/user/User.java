package model.user;

import model.enums.BackpackType;
import model.enums.TrashCanType;
import model.Player.inventory.Backpack;
import model.Player.inventory.Inventory;
import model.Player.inventory.TrashCan;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public class User {
    private final String username;
    private String password;
    private String hashedPassword;
    private String nickname;
    private String email;
    private String gender;
    private String securityQuestion;
    private String hashedSecurityAnswer;
    private int score = 0;
    private int gameCount = 0;
    private int energy;
    private Inventory inventory;
    private Wallet wallet;


    public User(String username, String password, String nickname,
                String email, String gender, String securityQuestion, String securityAnswer) {
        this.username = username;
        this.hashedPassword =hashSHA256(password);
        this.nickname = nickname;
        this.email = email;
        this.gender = gender;
        this.securityQuestion = securityQuestion;
        this.hashedSecurityAnswer = hashSHA256(securityAnswer);
        this.energy = 200;
        this.inventory = new Inventory(new Backpack(BackpackType.SMALL),new TrashCan(TrashCanType.BASIC));
        this.wallet = new Wallet();
    }
    private String hashSHA256(String input) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hash = digest.digest(input.getBytes());
            StringBuilder hexString = new StringBuilder();
            for (byte b : hash) {
                String hex = Integer.toHexString(0xff & b);
                if (hex.length() == 1) hexString.append('0');
                hexString.append(hex);
            }
            return hexString.toString();
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException("SHA-256 algorithm not available", e);
        }
    }

    public String getUsername() {
        return username;
    }

    public boolean checkPassword(String newPassword) {
        return newPassword.equals(password);
    }

    public void changePassword(String newPassword) {
        this.password = newPassword;
    }

    public void changeNickname(String newNick) {
        this.nickname = newNick;
    }

    public void changeEmail(String newEmail) {
        this.email = newEmail;
    }

    public String getNickname() {
        return nickname;
    }

    public String getEmail() {
        return email;
    }

    public String getGender() {
        return gender;
    }


    public int getScore() {
        return score;
    }

    public int getGameCount() {
        return gameCount;
    }

    public void increaseScore(int amount) {
        this.score += amount;
    }

    public void incrementGameCount() {
        this.gameCount++;
    }

    public Inventory getInventory() {
        return inventory;
    }

    public Wallet getWallet() {
        return wallet;
    }

    private EnergySystem energySystem = new EnergySystem();

    public void performAction(int energyCost) {
        energySystem.consume(energyCost);
        if (energySystem.isPassedOut()) {
        }

    }
}
