package model.game;

import model.enums.TileType;
import model.game.Position;
import model.game.Region;
import model.items.Item; // فرض میکنیم کلاس آیتم داری


public class Tile {

    private final Position position;   // موقعیت تایل تو نقشه
    private TileType type;             // نوع تایل (درخت، آب، خاک، و ...)
    private Item item;                 // آیتمی که روی این تایل هست (میتونه null باشه)
    private boolean isWalkable;         // آیا پلیر میتونه بره روی این تایل؟
    private Region region;             // این تایل متعلق به کدوم ریجن هست (مزرعه/دهکده/مارکت)

    // Constructor: موقعیت و ریجن رو میگیره و تایل رو به صورت EMPTY میسازه
    public Tile(Position position, Region region) {
        this.position = position;
        this.region = region;
        this.type = TileType.EMPTY;
        this.item = null;
        this.isWalkable = true;
    }

    // ====== Getter and Setter ======

    public Position getPosition() {
        return position;
    }

    public TileType getType() {
        return type;
    }

    public void setType(TileType type) {
        this.type = type;
        updateWalkableStatus(); // هر وقت نوع تایل تغییر کرد، walkable بودنش هم آپدیت بشه
    }

    public Item getItem() {
        return item;
    }

    public void setItem(Item item) {
        this.item = item;
    }

    public boolean isWalkable() {
        return isWalkable;
    }

    public Region getRegion() {
        return region;
    }

    public void setRegion(Region region) {
        this.region = region;
    }

    // ====== Private Methods ======

    // آپدیت کردن وضعیت قابل عبور بودن بر اساس نوع تایل
    private void updateWalkableStatus() {
        switch (this.type) {
            //case WATER:
            case ROCK:
            case TREE:
            case NPC_HOUSE:
            case SHOP:
                this.isWalkable = false;
                break;
            default:
                this.isWalkable = true;
                break;
        }
    }
}
