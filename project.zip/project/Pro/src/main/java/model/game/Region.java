package model.game;

public abstract class Region {

    public final int width;
    public final int height;
    public int offsetX;  // شروع X در نقشه‌ی بزرگ (WorldMap)
    public int offsetY;  // شروع Y در نقشه‌ی بزرگ (WorldMap)

    public Region(int width, int height) {
        this.width = width;
        this.height = height;
        this.offsetX = 0;
        this.offsetY = 0;
    }

    public int getWidth() {
        return width;
    }

    public int getHeight() {
        return height;
    }

    public int getOffsetX() {
        return offsetX;
    }

    public int getOffsetY() {
        return offsetY;
    }

    public void setOffset(int offsetX, int offsetY) {
        this.offsetX = offsetX;
        this.offsetY = offsetY;
    }
    public abstract void printRegion();

}


