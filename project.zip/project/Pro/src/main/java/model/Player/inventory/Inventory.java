package model.Player.inventory;

import model.Result;
import model.items.Item;

import java.util.*;

public class Inventory {
    private Map<String,Integer> items = new HashMap<>();
    private Backpack backpack;
    private TrashCan trashCan;

    public Inventory(Backpack backpack, TrashCan trashCan) {
        this.backpack = backpack;
        this.trashCan = trashCan;
    }

    public Result addItem(Item item) {
        String name = item.getName().toLowerCase();
        if (!items.containsKey(name) && items.size() >= backpack.getCapacity()) {
            return Result.failure("Backpack is full! Cannot add new item type: " + item.getName());
        }
        items.put(name, items.getOrDefault(name, 0) + 1);
        return Result.success(item.getName() + " added successfully. Quantity: " + items.get(name));
    }

    public boolean hasItem(String name) {
        return items.containsKey(name.toLowerCase());
    }

    public int  getItemInstance(String name) {
        return items.getOrDefault(name.toLowerCase(), 0);
    }

    public Result removeItemWithTrash(String name, int qty, Item prototype) {
        String key = name.toLowerCase();
        Integer current = items.get(key);
        if (current == null) {
            return Result.failure("Item not found in inventory: " + name);
        }
        int removeQty = Math.min(qty, current);
        double refundRate = trashCan.getType().getRefundRate();
        int refund = (int) Math.round(prototype.getSellPrice() * refundRate) * removeQty;
        int remaining = current - removeQty;
        if (remaining > 0) {
            items.put(key, remaining);
        } else {
            items.remove(key);
        }
        return Result.success("Removed " + removeQty + " x " + name + ". You got " + refund + " coins back.");
    }


    public Map<String, Integer> getItems() {
        return new HashMap<>(items);
    }
    public int usedSlots() {
        return items.size();
    }

    public int getRemainingCapacity() {
        return backpack.getCapacity() - usedSlots();
    }
    public Set<String> getItemNames() {
        return items.keySet();
    }
}
