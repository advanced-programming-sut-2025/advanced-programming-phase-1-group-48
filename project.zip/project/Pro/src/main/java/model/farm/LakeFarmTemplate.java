package model.farm;

import model.enums.TileType;

public class LakeFarmTemplate implements FarmTemplate {
    private static final int WIDTH = 20;
    private static final int HEIGHT = 20;

    @Override
    public TileType[][] generateLayout() {
        TileType[][] layout = new TileType[HEIGHT][WIDTH];

        for (int i = 0; i < HEIGHT; i++) {
            for (int j = 0; j < WIDTH; j++) {
                layout[i][j] = TileType.EMPTY;
            }
        }
        for (int i = 7; i <= 11; i++) {
            for (int j = 7; j <= 11; j++) {
                layout[i][j] = TileType.LAKE;
            }
        }
        layout[1][WIDTH / 2] = TileType.CABIN;

        for (int i = HEIGHT - 3; i < HEIGHT; i++) {
            for (int j = WIDTH - 3; j < WIDTH; j++) {
                layout[i][j] = TileType.GREENHOUSE;
            }
        }

        for (int i = 2; i <= 4; i++) {
            for (int j = 1; j <= 3; j++) {
                layout[i][j] = TileType.QUARRY;
            }
        }

        return layout;
    }

    @Override
    public int getWidth() {
        return WIDTH;
    }

    @Override
    public int getHeight() {
        return HEIGHT;
    }

    @Override
    public String getName() {
        return "Lake Farm";
    }
}
