package model.farm;

import model.enums.TileType;
import model.game.Position;
import model.game.Region;
import model.game.Tile;

public class FarmRegion extends Region {

    private final int width;
    private final int height;
    private final Tile[][] tiles;

    public FarmRegion(FarmTemplate template) {
        super(template.getWidth(), template.getHeight());
        this.width = template.getWidth();
        this.height = template.getHeight();
        this.tiles = new Tile[height][width];

        TileType[][] layout = template.generateLayout();

        for (int i = 0; i < height; i++) {
            for (int j = 0; j < width; j++) {
                Position pos = new Position(i, j);
                Tile tile = new Tile(pos, this);
                tile.setType(layout[i][j]);
                tiles[i][j] = tile;
            }
        }
    }

    public Tile getTileAt(int x, int y) {
        if (isInsideBounds(x, y)) {
            return tiles[x][y];
        }
        return null;
    }

    public boolean isInsideBounds(int x, int y) {
        return (x >= 0 && x < height && y >= 0 && y < width);
    }

    public int getWidth() {
        return width;
    }

    public int getHeight() {
        return height;
    }

    public Tile[][] getTiles() {
        return tiles;
    }

    // برای تست: چاپ کل نقشه
    public void printRegion() {
        for (int i = 0; i < height; i++) {
            for (int j = 0; j < width; j++) {
                switch (tiles[i][j].getType()) {
                    case EMPTY:
                        System.out.print(". ");
                        break;
                    case TREE:
                        System.out.print("T ");
                        break;
                    case ROCK:
                        System.out.print("R ");
                        break;
                    //case WATER:
                    case LAKE:
                        System.out.print("L ");
                        break;
                    case CABIN:
                        System.out.print("C ");
                        break;
                    case GREENHOUSE:
                        System.out.print("G ");
                        break;
                    case QUARRY:
                        System.out.print("Q ");
                        break;
                    case NPC_HOUSE:
                        System.out.print("N ");
                        break;
                    case SHOP:
                        System.out.print("S ");
                        break;
                    default:
                        System.out.print("? ");
                        break;
                }
            }
            System.out.println();
        }
    }
}
