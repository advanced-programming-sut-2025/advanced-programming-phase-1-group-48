package model.farm;

import model.enums.TileType;

public class DefaultFarmTemplate implements FarmTemplate {

    private static final int WIDTH = 20;
    private static final int HEIGHT = 20;

    @Override
    public TileType[][] generateLayout() {
        TileType[][] layout = new TileType[HEIGHT][WIDTH];

        for (int i = 0; i < HEIGHT; i++) {
            for (int j = 0; j < WIDTH; j++) {
                layout[i][j] = TileType.EMPTY;
            }
        }

        layout[0][0] = TileType.LAKE;
        layout[0][1] = TileType.LAKE;
        layout[1][0] = TileType.LAKE;
        layout[1][1] = TileType.LAKE;

        for (int i = 3; i <= 5; i++) {
            for (int j = 8; j <= 10; j++) {
                layout[i][j] = TileType.GREENHOUSE;
            }
        }

        layout[HEIGHT - 2][1] = TileType.CABIN;

        for (int i = HEIGHT - 3; i < HEIGHT; i++) {
            for (int j = 8; j <= 10; j++) {
                layout[i][j] = TileType.QUARRY;
            }
        }

        return layout;
    }

    @Override
    public int getWidth() {
        return WIDTH;
    }

    @Override
    public int getHeight() {
        return HEIGHT;
    }

    @Override
    public String getName() {
        return "Default Farm";
    }
}

