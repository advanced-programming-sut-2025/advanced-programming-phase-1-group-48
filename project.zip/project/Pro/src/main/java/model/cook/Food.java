package model.cook;

public class Food {
    //TODO
}
