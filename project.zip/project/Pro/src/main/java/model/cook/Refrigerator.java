package model.cook;

import model.Player.inventory.Backpack;
import model.Player.inventory.Inventory;
import model.Player.inventory.TrashCan;

public class Refrigerator extends Inventory {
    public Refrigerator(Backpack backpack, TrashCan trashCan) {
        super(backpack, trashCan);
    }
    //TODO
}
