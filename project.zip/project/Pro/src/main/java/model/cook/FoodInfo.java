package model.cook;

public enum FoodInfo {
    //ect
    ;

    private int energyValue;
    private int sellPrice;
    private Buff buff;
    private String source;
    private int price;



    FoodInfo(int energyValue, int SellPrice , Buff buff, String source, int price) {
        this.energyValue = energyValue;
        this.sellPrice = SellPrice;
        this.buff = buff;
        this.source = source;
    }

    public int getEnergyValue() {
        return energyValue;
    }

    public int getSellPrice() {
        return sellPrice;
    }


}
