package model.items;

public class SimpleItem extends Item {
    private final int sellPrice;

    public SimpleItem(String name, char displayChar, int sellPrice) {
        super(name, displayChar);
        this.sellPrice = sellPrice;
    }

    @Override
    public void interact() {
    }

    @Override
    public int getSellPrice() {
        return sellPrice;
    }
}
