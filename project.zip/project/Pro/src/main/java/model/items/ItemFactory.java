package model.items;

import model.Plant.Seed;
import model.Player.inventory.Backpack;
import model.Player.inventory.Inventory;
import model.Player.inventory.TrashCan;
import model.Result;
import model.Tools.*;
import model.enums.*;
// فقط چیزهایی اینجا ساخته میشود که باید در inventory ساخته شود
public class ItemFactory {

    public static Item createItem(String name, Inventory inventory) {
        if (inventory.getRemainingCapacity() == 0) {
            return null;
        }
        Item item;
        switch (name.toLowerCase()) {
            case "basic axe":
                item = new Axe(AxeType.BASIC);
                break;
            case "basic pickaxe":
                item = new Pickaxe(PickaxeType.BASIC);
                break;
            case "basic hoe":
                item = new Hoe(HoeType.BASIC);
                break;
            case "basic watering can":
                item = new WateringCan(WateringCanType.BASIC);
                break;
            case "wood":
                item = new Resource("Wood", 'W', 10);
                break;
            case "copper ore":
                item = new Resource("Copper Ore", 'C', 75);
                break;
            case "iron ore":
                item = new Resource("Iron Ore", 'I', 150);
                break;
            case "gold ore":
                item = new Resource("Gold Ore", 'G', 400);
                break;
            case "coal":
                item = new Resource("Coal", 'L', 150); // 'L' برای "coal" چون C با copper گرفته شده
                break;
            case "treesap":
                item = new SimpleItem("TreeSap", 'T', 20);
                break;
            default:
                throw new IllegalArgumentException("Unknown item: " + name);
        }
        inventory.addItem(item);
        return item;
    }
}
