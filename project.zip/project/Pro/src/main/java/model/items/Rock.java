package model.items;


public class Rock extends Item {
    public Rock() {
        super("Rock", 'R');
    }

    @Override
    public void interact() {
        // Todo
    }
    @Override
    public int getSellPrice() {
        return 0;// هزینه ان (قیمت ان )
    }
}
