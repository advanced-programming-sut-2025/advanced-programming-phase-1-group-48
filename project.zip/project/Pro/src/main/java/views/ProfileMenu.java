package views;

import java.util.Scanner;

public class ProfileMenu implements AppMenu{
    public void handleInput(String command, Scanner scanner) {

    }
}
