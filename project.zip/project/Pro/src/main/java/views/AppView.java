package views;

public class AppView {
    public static void printMessage(String message) {
        System.out.println(message);
    }
}
