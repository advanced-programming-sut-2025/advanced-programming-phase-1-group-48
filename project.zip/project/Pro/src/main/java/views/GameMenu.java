package views;

import controllers.ShopController;
import controllers.SignUpMenuController;
import controllers.gameMenuController;
import model.Result;

import java.util.Scanner;

public class GameMenu implements AppMenu {
    public void handleInput(String command, Scanner scanner) {
    if (command.startsWith("show") || command.startsWith("purchase")|| command.startsWith("time")|| command.startsWith("date")|| command.startsWith("datetime")|| command.startsWith("day of the week")
    || command.startsWith("cheat")||command.startsWith("season")||command.startsWith("game")||command.startsWith("weather")|| command.startsWith("")) {
        Result result = gameMenuController.gameMenu(command, scanner);
        AppView.printMessage(result.message());
    }
    }
}