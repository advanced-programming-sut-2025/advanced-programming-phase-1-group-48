package views;

import controllers.SignUpMenuController;
import model.Result;
import model.enums.MenuCommands;

import java.util.Scanner;

public class SignUpMenu implements AppMenu{
    public void handleInput(String command, Scanner scanner) {
        if(command.matches(MenuCommands.REGISTER.getPattern().pattern())){
            Result result = SignUpMenuController.signup(command, scanner);
            AppView.printMessage(result.message());
        }
    }
}
