package views;

import java.util.Scanner;

public class LoginMenu implements AppMenu{
    public void handleInput(String command, Scanner scanner) {

    }
}
