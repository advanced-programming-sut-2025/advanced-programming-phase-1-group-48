package controllers;

import model.Result;

public class TradeMenuController {
    public Result tradeHistory() {
        return null;
    }
    public Result TradeList(){
        return null;
    }
    public Result TradeResponse(){
        return null;
    }
    public Result exitTrade() {
        return null;
    }


}
