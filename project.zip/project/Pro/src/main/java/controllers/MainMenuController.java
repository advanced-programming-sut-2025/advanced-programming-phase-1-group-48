package controllers;

public class MainMenuController {
    public static void enterDiffrentMenu(){

    }
}
