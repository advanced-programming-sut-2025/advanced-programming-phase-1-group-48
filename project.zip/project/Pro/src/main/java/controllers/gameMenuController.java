package controllers;

import model.Result;
import model.Weather.DateAndTime;
import model.Weather.Thunderbolt;
import model.Weather.Weather;
import model.enums.WeatherType;

import java.util.Scanner;

import static controllers.ShopController.handlePurchase;

public class gameMenuController {
    public static Result gameMenu(String command, Scanner scanner) {
        String[] parts = command.trim().split("\\s+");

        switch (parts[0].toLowerCase()) {
            case "show":
                if (parts.length >= 3 && parts[1].equals("all")) {
                    if (parts[2].equals("products")) {
                        Result.success(ShopController.showAllProducts());
                    } else if (parts[2].equals("available") &&
                            parts.length >= 4 &&
                            parts[3].equals("products")) {
                        Result.success(ShopController.showAvailableProducts());
                    } else {
                        Result.failure("Invalid command");
                    }
                } else {
                    Result.failure("Invalid command");
                }
                break;

            case "purchase":
                handlePurchase(parts);
                break;

            case "cheat":
                
                if (parts.length == 4 && parts[1].equals("add") && parts[3].equals("dollars")) {
                    try {
                        int amount = Integer.parseInt(parts[2]);

                    } catch (NumberFormatException e) {
                        System.out.println("مقدار نامعتبر برای پول.");
                    }

                    // cheat advance time Xh
                } else if (parts.length == 4 &&
                        parts[1].equals("advance") &&
                        parts[2].equals("time")) {

                    String timeStr = parts[3];
                    if (timeStr.endsWith("h")) {
                        try {
                            int hours = Integer.parseInt(timeStr.substring(0, timeStr.length() - 1));
                            if (hours < 0) {
                                Result.failure("time cannot be negative.");
                            } else {
                                DateAndTime.advanceHour(hours);
                            }
                        } catch (NumberFormatException e) {
                            Result.failure("invalid command");
                        }
                    }

                }

                // cheat advance date Xd
                else if (parts.length == 4 &&
                        parts[1].equals("advance") &&
                        parts[2].equals("date")) {

                    String dateStr = parts[3];
                    if (dateStr.endsWith("d")) {
                        try {
                            int days = Integer.parseInt(dateStr.substring(0, dateStr.length() - 1));
                            if (days < 0) {
                                Result.failure("date cannot be negative.");
                            } else {
                                DateAndTime.advanceDay(days);
                            }
                        } catch (NumberFormatException e) {
                            Result.failure("invalid command");
                        }
                    }

                    // cheat set weather TYPE
                } else if (parts.length == 4 &&
                        parts[1].equals("weather") &&
                        parts[2].equals("set")) {

                    try {
                        WeatherType wt = WeatherType.valueOf(parts[3]);
                        Weather.getInstance().cheatSetTomorrowWeather(wt);
                    } catch (IllegalArgumentException e) {
                        Result.failure("unknown weather type: " + parts[3]);
                    }

                    // cheat Thor -l x,y
                } else if (parts.length == 4 &&
                        parts[1].equalsIgnoreCase("Thor") &&
                        parts[2].equalsIgnoreCase("-l")) {
                    try {
                        String[] xy = parts[3].split(",");
                        int x = Integer.parseInt(xy[0].trim());
                        int y = Integer.parseInt(xy[1].trim());
                        Thunderbolt.getInstance().strikeAt(x, y);
                        return Result.success(
                                String.format("Cheat: Lightning struck at (%d,%d)", x, y)
                        );
                    } catch (Exception e) {
                        return Result.failure(
                                "Invalid coordinates. Usage: cheat Thor -l <x,y>"
                        );
                    }

                } else {
                    Result.failure("invalid cheat command");
                }

                break;

            case "time": {
                Result.failure("hour: " + DateAndTime.getHour());
            } break;

            case "date": {
                Result.failure("day: " + DateAndTime.getDay());
            } break;

            case "datetime": {
                Result.failure("Day: " + DateAndTime.getDay() +
                        " hour: " + DateAndTime.getHour());
            } break;

            case "day of the week": {
                DateAndTime.displayDayOfWeek();
            } break;

            case "season": {
                Result.failure("season: " + DateAndTime.getCurrentSeason());
            } break;

            case "weather": {
                if (parts.length == 1) {
                    String todayWeather = Weather.getInstance().getToday().name();
                    Result.failure(todayWeather);
                } else {
                    String tomorrowWeather = Weather.getInstance().getTomorrow().name();
                    Result.failure(tomorrowWeather);
                }
            } break;

            default:
                System.out.println("دستور ناشناخته.");
        }

        return Result.success("kmk");
    }
}
