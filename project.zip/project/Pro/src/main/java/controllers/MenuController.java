package controllers;

import views.AppMenu;

import java.util.Scanner;

public class MenuController {
    private static AppMenu currentMenu;
    public static void setMenu(AppMenu menu) {
        currentMenu = menu;
    }
    public static void handleCommand(String command, Scanner scanner) {
        if (currentMenu != null) {
            currentMenu.handleInput(command, scanner);
        }
    }
}
