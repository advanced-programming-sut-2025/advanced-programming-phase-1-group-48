package controllers;

public class ShopController {
    public static String showAllProducts() {

    }
    public static String showAvailableProducts() {

    }
    public static String handlePurchase(String[] parts){

    }
    public static String handleCheat(String[] parts){

    }
}
