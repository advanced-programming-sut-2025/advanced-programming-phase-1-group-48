package controllers;

import model.Player.Player;
import model.shop.ShopManager;

public class Game {
    private ShopManager shopManager;
    private Player player;
    public void start() {
        this.shopManager = new ShopManager();
    }
    public static Player getCurrentPlayer(){

    }
}
