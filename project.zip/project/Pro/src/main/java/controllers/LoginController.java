package controllers;

import model.Result;

public class LoginController {
    public static Result signup(){
        return new Result(true, "Signup ...");
    }
    public static Result enterMenu (){
        return new Result(true, "Enter Menu...");
        //AppView.setMenu();
    }
    public static Result showCurrentMenu(){
        return new Result(true, "Current Menu...");
    }
    public static Result randomPassword(){
        return new Result(true, "Random Password will be generated...");
    }

}
