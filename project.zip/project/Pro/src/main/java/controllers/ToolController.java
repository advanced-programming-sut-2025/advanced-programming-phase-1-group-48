package controllers;

import model.Player.inventory.Inventory;
import model.Result;
import model.Tools.Tool;
import model.game.Tile;
import model.Player.Player;
import model.items.Item;

import java.util.List;
import java.util.Set;

public class ToolController {
    public static void handleEquip( String toolName,Player player) {
        Inventory inv = player.getInventory();
        if (!inv.hasItem(toolName)) {
            Result.failure(toolName + " not in Backpack");
            return;
        }
        Item it = inv.getItemInstance(toolName);
        player.setEquippedItem(it);
        Result.success(toolName + " equipped");
    }
    public static void handleUse(Tile[][] map) {}
    public static void handleUpgrade(String toolName, boolean isAtBlacksmith) {

    }
    public static void showCurrentTool(Player player) {
        Item equipped = player.getEquippedItem();
        if (equipped == null || !(equipped instanceof Tool)) {
            Result.failure("You have no tool equipped!");
        } else {
            Tool currentTool = (Tool) equipped;
            Result.success("Current tool: " + currentTool.getName());
        }
    }
    public static void showAvailableTools(Player player) {
        Inventory inventory = player.getInventory();
        Set<String> itemNames = inventory.getItemNames();

        String[] toolKeywords = {"axe", "pickaxe", "hoe", "watering can", "fishing rod", "scythe",
                "milking bucket", "shears", "trash can"};
        boolean foundTool = false;
        for (String name : itemNames) {
            for (String keyword : toolKeywords) {
                if (name.toLowerCase().contains(keyword)) {
                    System.out.println("- " + name);
                    foundTool = true;
                    break;
                }
            }
        }

        if (!foundTool) {
            Result.failure("No tools found in your inventory.");
        }
    }
}