package model.Tools;


import model.game.Tile;
import model.Player;

public class Scythe extends Tool {

    public Scythe() {
        super("Scythe", 0, 2);
    }

    @Override
    public boolean use(Player player, Tile targetTile) {
        return false;
    }

    @Override
    public boolean canUseOn(Tile tile) {
        return false;
    }

    @Override
    public Tool upgrade() {
        return null;
    }
}
