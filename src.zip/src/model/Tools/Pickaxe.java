package model.Tools;

import model.game.Tile;
import model.Player;
import model.enums.PickaxeType;

public class Pickaxe extends Tool {
    private PickaxeType type;

    public Pickaxe(PickaxeType type) {
        super(type.getName(), type.getLevel(), type.getBaseEnergyCost());
        this.type = type;
    }
    private static int calculateBaseEnergyCost(int level) {
        switch (level) {
            case 0: return 5;  // Basic
            case 1: return 4;  // Copper
            case 2: return 3;  // Iron
            case 3: return 2;  // Gold
            case 4: return 1;  // Iridium
            default: return 5;
        }
    }

    @Override
    public boolean use(Player player, Tile targetTile) {
        return false;
    }

    @Override
    public boolean canUseOn(Tile tile) {
        return false;
    }

    @Override
    public Tool upgrade() {
        return this;
    }
}

