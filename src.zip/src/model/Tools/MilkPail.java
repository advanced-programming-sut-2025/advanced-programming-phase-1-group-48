package model.Tools;

import model.game.Tile;
import model.Player;

public class MilkPail extends Tool {

    public MilkPail() {
        super("Milk Pail", 0, 4);
    }

    @Override
    public boolean use(Player player, Tile targetTile) {
        return false;
    }

    @Override
    public boolean canUseOn(Tile tile) {
        return false;
    }

    @Override
    public Tool upgrade() {
        return null;
    }
}
