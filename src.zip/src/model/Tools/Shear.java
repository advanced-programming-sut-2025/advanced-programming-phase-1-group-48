package model.Tools;

import model.game.Tile;
import model.Player;

public class Shear extends Tool {

    public Shear() {
        super("Shear", 0, 4);
    }

    @Override
    public boolean use(Player player, Tile targetTile) {
            return false;
    }

    @Override
    public boolean canUseOn(Tile tile) {
        return false;
    }

    @Override
    public Tool upgrade() {
        return null;
    }
}

