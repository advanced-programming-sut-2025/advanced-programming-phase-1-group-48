package model.Tools;

import model.Player;
import model.game.Tile;

public abstract class Tool {
    protected String name;
    protected int level; // 0 = basic, 1 = copper, ...
    protected int baseEnergyCost;

    public Tool(String name, int level, int baseEnergyCost) {
        this.name = name;
        this.level = level;
        this.baseEnergyCost = baseEnergyCost;
    }

    public String getName() { return name; }

    public int getLevel() { return level; }

    public abstract boolean use(Player player, Tile targetTile);

    public abstract boolean canUseOn(Tile tile);

    public abstract Tool upgrade(); // returns upgraded version if possible
}
