package model.Tools;

import model.Player;
import model.game.Tile;


public class Hoe extends Tool {
    public Hoe(int level) {
        super("Hoe", level, calculateEnergy(level));
    }

    private static int calculateEnergy(int level) {
        return Math.max(1, 5 - level);
    }

    @Override
    public boolean use(Player player, Tile tile) {
        return true;
    }

    @Override
    public boolean canUseOn(Tile tile) {
        return false;
    }

    @Override
    public Tool upgrade() {
        return new Hoe(level + 1);
    }
}

