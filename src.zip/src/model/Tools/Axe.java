package model.Tools;


import model.Player;
import model.game.Tile;
import model.enums.AxeType;

public class Axe extends Tool {
    private AxeType type;

    public Axe(AxeType type) {
        super(type.getName(), type.getLevel(), type.getBaseEnergyCost());
        this.type = type;
    }

    @Override
    public boolean use(Player player, Tile targetTile) {
        return false;
    }

    @Override
    public boolean canUseOn(Tile tile) {
        return false;
    }

    @Override
    public Tool upgrade() {
        return null;
    }
}

