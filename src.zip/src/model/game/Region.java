package model.game;

public abstract class Region {
    protected String regionName;
    protected Position topLeft;
    protected int width;
    protected int height;

    public Region(String regionName, Position topLeft, int width, int height) {
        this.regionName = regionName;
        this.topLeft = topLeft;
        this.width = width;
        this.height = height;
    }

    public String getRegionName() {
        return regionName;
    }

    public Position getTopLeft() {
        return topLeft;
    }

    public int getWidth() { return width; }
    public int getHeight() { return height; }

    public abstract void printRegion();
}

