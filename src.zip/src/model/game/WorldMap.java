package model.game;

import java.util.List;

public class WorldMap {
    private int width;
    private int height;
    private List<Region> regions;

    public WorldMap(int width, int height, List<Region> regions) {
        this.width = width;
        this.height = height;
        this.regions = regions;
    }

    public List<Region> getRegions() {
        return regions;
    }

    public void addRegion(Region region) {
        regions.add(region);
    }

    public void printWorldMap() {
        // todo
    }

}
