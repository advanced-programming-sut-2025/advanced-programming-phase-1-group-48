package model.game;

import model.enums.TileType;
import model.items.Item;

public class Tile {
    private TileType type;
    private Item item;

    public Tile(TileType type) {
        this.type = type;
        this.item = null;
    }

    public TileType getType() {
        return type;
    }

    public void setType(TileType type) {
        this.type = type;
    }

    public Item getItem() {
        return item;
    }

    public void setItem(Item item) {
        this.item = item;
    }

    public char getDisplayChar() {
        if (item != null) {
            return item.getDisplayChar();
        }
        switch (type) {
            case EMPTY: return '.';
            case LAKE: return 'L';
            case CABIN: return 'C';
            case GREENHOUSE: return 'G';
            case QUARRY: return 'Q';
            case PATH: return 'P';
//            case TREE: return 'T';
//            case ROCK: return 'R';
//            case FORAGING: return 'F';
            default: return '?';
        }
    }

    public boolean isWalkable() {
        //to do
        return type != TileType.LAKE && type != TileType.CABIN && type != TileType.GREENHOUSE;
    }
}
