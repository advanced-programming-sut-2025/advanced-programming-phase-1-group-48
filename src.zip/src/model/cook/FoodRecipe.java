package model.cook;

import model.items.Item;

import java.util.ArrayList;
import java.util.HashMap;

public enum FoodRecipe {
    FriedEgg();

    public final HashMap<Item, Integer> recipe;

    FoodRecipe() {
        this.recipe = new HashMap<>();
    }
}
