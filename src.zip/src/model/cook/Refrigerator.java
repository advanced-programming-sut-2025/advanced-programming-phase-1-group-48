package model.cook;

import model.user.inventory.Backpack;
import model.user.inventory.Inventory;
import model.user.inventory.TrashCan;

public class Refrigerator extends Inventory {
    public Refrigerator(Backpack backpack, TrashCan trashCan) {
        super(backpack, trashCan);
    }
    //TODO
}
