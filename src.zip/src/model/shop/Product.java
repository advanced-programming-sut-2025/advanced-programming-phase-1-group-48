package model.shop;

public class Product {
    private String name;
    private int price;
    private int stockLimitPerDay;
    private int remainingToday;
    public Product(String name, int price, int stockLimitPerDay) {
        this.name = name;
        this.price = price;
        this.stockLimitPerDay = stockLimitPerDay;
        this.remainingToday = stockLimitPerDay;
    }

    public boolean isAvailable() {
        return remainingToday > 0;
    }

    public boolean purchase(int quantity) {
        if (quantity <= remainingToday) {
            remainingToday -= quantity;
            return true;
        }
        return false;
    }

    public void resetDaily() {
        remainingToday = stockLimitPerDay;
    }

    public String getName() {
        return name;
    }
}

