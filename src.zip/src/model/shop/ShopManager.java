package model.shop;

import model.enums.ShopType;

import java.util.HashMap;
import java.util.Map;

public class ShopManager {
    private Map<ShopType, Shop> shops = new HashMap<>();

    public void registerShop(Shop shop) {
        shops.put(shop.getType(), shop);
    }

    public Shop getShop(ShopType type) {
        return shops.get(type);
    }

    public void resetDailyStock() {
        for (Shop shop : shops.values()) {
            shop.getAllProducts().forEach(Product::resetDaily);
        }
    }
}

