package model.enums;


public enum PickaxeType {
    BASIC("Basic Pickaxe", 0, 5),
    COPPER("Copper Pickaxe", 1, 4),
    IRON("Iron Pickaxe", 2, 3),
    GOLD("Gold Pickaxe", 3, 2),
    IRIDIUM("Iridium Pickaxe", 4, 1);

    private final String name;
    private final int level;
    private final int baseEnergyCost;

    PickaxeType(String name, int level, int baseEnergyCost) {
        this.name = name;
        this.level = level;
        this.baseEnergyCost = baseEnergyCost;
    }

    public String getName() {
        return name;
    }

    public int getLevel() {
        return level;
    }

    public int getBaseEnergyCost() {
        return baseEnergyCost;
    }
}

