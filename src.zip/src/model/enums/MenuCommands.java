package model.enums;

public enum MenuCommands {
}
