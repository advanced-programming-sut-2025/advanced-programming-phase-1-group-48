package model.enums;

public enum ShopType {
    BLACKSMITH,
    JOJAMART,
    GENERAL_STORE,
    CARPENTER,
    FISH_SHOP,
    RANCH,
    SALOON
}
