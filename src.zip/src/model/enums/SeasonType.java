package model.enums;

public enum SeasonType {
    Spring,
    Summer,
    Fall,
    Winter;
}
