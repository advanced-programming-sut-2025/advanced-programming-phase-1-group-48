package model.enums;

public enum FriendshipLevel {
    Enemy,
    Stranger,
    Friend,
    CloseFriend,
    BestFriend,
    Partner,
    Spouse;
}
