package model.enums;


public enum WeatherType {
    SUNNY,
    RAIN,
    STORM,
    SNOW,

}

