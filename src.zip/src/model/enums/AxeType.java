package model.enums;


public enum AxeType {
    BASIC("Basic Axe", 0, 5),
    COPPER("Copper Axe", 1, 4),
    IRON("Iron Axe", 2, 3),
    GOLD("Gold Axe", 3, 2),
    IRIDIUM("Iridium Axe", 4, 1);

    private final String name;
    private final int level;
    private final int baseEnergyCost;

    AxeType(String name, int level, int baseEnergyCost) {
        this.name = name;
        this.level = level;
        this.baseEnergyCost = baseEnergyCost;
    }

    public String getName() { return name; }
    public int getLevel() { return level; }
    public int getBaseEnergyCost() { return baseEnergyCost; }
}

