package model.enums;

public enum WateringCanType {
    BASIC("Basic Watering Can", 0, 40, 5),
    COPPER("Copper Watering Can", 1, 55, 4),
    IRON("Iron Watering Can", 2, 70, 3),
    GOLD("Gold Watering Can", 3, 85, 2),
    IRIDIUM("Iridium Watering Can", 4, 100, 1);

    private final String name;
    private final int level;
    private final int capacity;
    private final int baseEnergyCost;

    WateringCanType(String name, int level, int capacity, int baseEnergyCost) {
        this.name = name;
        this.level = level;
        this.capacity = capacity;
        this.baseEnergyCost = baseEnergyCost;
    }

    public String getName() { return name; }
    public int getLevel() { return level; }
    public int getCapacity() { return capacity; }
    public int getBaseEnergyCost() { return baseEnergyCost; }
}
