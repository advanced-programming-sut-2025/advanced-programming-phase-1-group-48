package model.enums;

public enum BackpackType {
    BASIC("Basic Backpack", 12, 0),
    MEDIUM("Medium Backpack", 24, 2000),
    DELUXE("Deluxe Backpack", Integer.MAX_VALUE, 10000);

    private final String name;
    private final int capacity;
    private final int price;

    BackpackType(String name, int capacity, int price) {
        this.name = name;
        this.capacity = capacity;
        this.price = price;
    }

    public String getName() { return name; }
    public int getCapacity() { return capacity; }
    public int getPrice() { return price; }
}
