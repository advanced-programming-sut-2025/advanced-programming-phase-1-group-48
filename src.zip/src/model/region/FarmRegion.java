package model.region;

import model.game.Region;
import model.game.Position;
import model.farm.Farm;

public class FarmRegion extends Region {
    private Farm farm;

    public FarmRegion(String regionName, Position topLeft, int width, int height, Farm farm) {
        super(regionName, topLeft, width, height);
        this.farm = farm;
    }

    @Override
    public void printRegion() {}

    public Farm getFarm() {
        return farm;
    }
}
