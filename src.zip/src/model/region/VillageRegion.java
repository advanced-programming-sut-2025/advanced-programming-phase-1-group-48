package model.region;

import model.game.GameMap;
import model.game.Position;
import model.game.Region;
import model.NPC.NPC;
import model.building.Buildings;

import java.util.ArrayList;
import java.util.List;

public class VillageRegion extends Region {
    private GameMap villageMap;
    private List<NPC> npcs;
    private List<Buildings> buildings;

    public VillageRegion(String regionName, Position topLeft, int width, int height) {
        super(regionName, topLeft, width, height);
        this.villageMap = new GameMap(width, height);
        this.npcs = new ArrayList<>();
        this.buildings = new ArrayList<>();
        initializeVillage();
    }

    private void initializeVillage() {
    }

    public void addNPC(NPC npc) {
        npcs.add(npc);
    }

    public void addBuilding(Buildings building) {
        buildings.add(building);
    }

    @Override
    public void printRegion() {
    }

    public GameMap getVillageMap() {
        return villageMap;
    }

    public List<NPC> getNpcs() {
        return npcs;
    }

    public List<Buildings> getBuildings() {
        return buildings;
    }
}
