package model.building.npcHomes;

import model.game.Position;

public class RobinHome extends NpcHouse {
    public RobinHome(String name, String npcName, Position topLeft, int width, int height) {
        super(name, npcName, topLeft, width, height);
    }
}
