package model.building.npcHomes;

import model.game.Position;

public class SebastienHome extends NpcHouse {
    public SebastienHome(String name, String npcName, Position topLeft, int width, int height) {
        super(name, npcName, topLeft, width, height);
    }
}
