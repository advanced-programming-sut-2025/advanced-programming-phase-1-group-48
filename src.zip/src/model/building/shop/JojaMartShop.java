package model.building.shop;


import model.game.Position;
import model.enums.ShopType;
import java.time.LocalTime;

public class JojaMartShop extends ShopBuilding {
    public JojaMartShop(Position pos) {
        super("JojaMart", pos, 6, 6, LocalTime.of(9, 0), LocalTime.of(23, 0), "Morris");
    }

    @Override
    public ShopType getShopType() {
        return ShopType.JOJAMART;
    }
}
