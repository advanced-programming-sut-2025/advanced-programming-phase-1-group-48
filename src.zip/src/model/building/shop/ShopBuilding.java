package model.building.shop;


import model.building.Buildings;
import model.game.Position;
import model.shop.Shop;
import java.time.LocalTime;

public abstract class ShopBuilding extends Buildings {
    protected Shop shop;
    protected LocalTime openTime;
    protected LocalTime closeTime;
    protected String owner;

    public ShopBuilding(String name, Position pos, int width, int height, LocalTime open, LocalTime close, String owner) {
        super(name, pos, width, height);
        this.openTime = open;
        this.closeTime = close;
        this.owner = owner;
        this.shop = new Shop(getShopType(), owner, openTime, closeTime);
    }

    public boolean isOpen(LocalTime currentTime) {
        return currentTime.isAfter(openTime) && currentTime.isBefore(closeTime);
    }

    public abstract model.enums.ShopType getShopType();

    public Shop getShop() {
        return shop;
    }

    @Override
    public void interact() {
    }
}

