package model.building.shop;

import model.game.Position;
import model.enums.ShopType;
import java.time.LocalTime;

public class GeneralStore extends ShopBuilding {
    public GeneralStore(Position pos) {
        super("General Store", pos, 6, 5, LocalTime.of(9, 0), LocalTime.of(17, 0), "Pierre");
    }

    @Override
    public ShopType getShopType() {
        return ShopType.GENERAL_STORE;
    }
}
