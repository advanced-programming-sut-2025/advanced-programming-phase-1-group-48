package model;

public class Map {

}
