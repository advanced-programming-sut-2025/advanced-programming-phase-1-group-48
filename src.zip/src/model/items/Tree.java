package model.items;

public class Tree extends Item {
    public Tree() {
        super("Tree", 'T');
    }

    @Override
    public void interact() {
        //todo
    }
}

