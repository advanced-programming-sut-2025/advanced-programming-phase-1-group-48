package model.items;


public class ForagingItem extends Item {
    public ForagingItem() {
        super("ForagingItem", 'F');
    }

    @Override
    public void interact() {
        // TODO
    }
}
