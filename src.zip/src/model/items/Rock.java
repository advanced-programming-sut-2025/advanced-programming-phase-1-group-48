package model.items;


public class Rock extends Item {
    public Rock() {
        super("Rock", 'R');
    }

    @Override
    public void interact() {
        // Todo
    }
}
