package model.items;

import java.util.ArrayList;

public class UncraftableItem {
    private ArrayList<String> inedible;
    //..ect

    //TODO
}
