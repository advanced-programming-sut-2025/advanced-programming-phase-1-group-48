package model;

import java.util.ArrayList;

public class App {
    private ArrayList<Player> currentPlayers;

}
