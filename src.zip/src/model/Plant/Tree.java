package model.Plant;

import java.util.ArrayList;

public class Tree {
    private String name;
    private String sapling;
    private ArrayList<Integer>stage;
    private int harvestTime;
    private String fruit;
    private int harvestCycle;
    private int PriceOfFruit;
    private boolean isFruitEdible;
    private int energyOfFruit;
    private String season;

    Tree(String name,String sapling,ArrayList<Integer> stage,int harvestTime, String fruit,int harvestCycle, int PriceOfFruit, boolean isFruitEdible,int energyOfFruit,String season) {
        this.name = name;
        this.sapling = sapling;
        this.stage = stage;
        this.harvestTime = harvestTime;
        this.fruit = fruit;
        this.harvestCycle = harvestCycle;
        this.PriceOfFruit = PriceOfFruit;
        this.isFruitEdible = isFruitEdible;
        this.energyOfFruit = energyOfFruit;
        this.season = season;

    }

    //TODO

    public String getName() {
        return name;
    }

    public int getHarvestTime() {
        return harvestTime;
    }

    public ArrayList<Integer> getStage() {
        return stage;
    }

    public String getFruit() {
        return fruit;
    }

    public int getHarvestCycle() {
        return harvestCycle;
    }

    public int getPriceOfFruit() {
        return PriceOfFruit;
    }

    public boolean isFruitEdible() {
        return isFruitEdible;
    }

    public int getEnergyOfFruit() {
        return energyOfFruit;
    }

    public String getSeason() {
        return season;
    }

    public void setStage(ArrayList<Integer> stage) {
        this.stage = stage;
    }

    public void setHarvestTime(int harvestTime) {
        this.harvestTime = harvestTime;
    }

    public void setHarvestCycle(int harvestCycle) {
        this.harvestCycle = harvestCycle;
    }

    public void setPriceOfFruit(int priceOfFruit) {
        PriceOfFruit = priceOfFruit;
    }

    public void setEnergyOfFruit(int energyOfFruit) {
        this.energyOfFruit = energyOfFruit;
    }
}
