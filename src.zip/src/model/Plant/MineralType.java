package model.Plant;

public enum MineralType {
    Quarts(),
}
