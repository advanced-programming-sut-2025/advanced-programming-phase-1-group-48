package model.Plant;

public enum SeedType {
    Jazz(),
}
