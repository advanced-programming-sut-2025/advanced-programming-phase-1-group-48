package model.Plant;

import model.items.Item;

import java.util.ArrayList;

public class Crop  {
    private String name;
    private String seed;
    private int growthTime;
    private int price;
    private int numberOfStage;
    private boolean eatable;
    private boolean oneTime;
    private boolean canBecomeGiant;
    private int numberOfEaten;
    private String season;
    private int energy;
    private boolean doLrrigation=false;

    public boolean isDoLrrigation() {
        return doLrrigation;
    }

    public void setDoLrrigation(boolean doLrrigation) {
        this.doLrrigation = doLrrigation;
    }

    public boolean isDoFertilizing() {
        return doFertilizing;
    }

    public void setDoFertilizing(boolean doFertilizing) {
        this.doFertilizing = doFertilizing;
    }

    private boolean doFertilizing=false;

    Crop(String name, String seed, int growthTime, int price, int numberOfStage, boolean eatable, boolean oneTime, String  season, boolean canBecomeGiant, int energy, boolean doLrrigation, boolean doFertilizing) {
        this.name = name;
        this.seed = seed;
        this.growthTime = growthTime;
        this.price = price;
        this.numberOfStage = numberOfStage;
        this.eatable =eatable;
        this.oneTime = oneTime;
        this.numberOfEaten = numberOfStage;
        this.season = season;
        this.canBecomeGiant = canBecomeGiant;
        this.energy = energy;
    }

    //TODO

    public int getEnergy() {
        return energy;
    }

    public String getName() {
        return name;
    }

    public String getSeed() {
        return seed;
    }

    public int getGrowthTime() {
        return growthTime;
    }

    public int getPrice() {
        return price;
    }

    public int getNumberOfStage() {
        return numberOfStage;
    }

    public boolean isEatable() {
        return eatable;
    }

    public boolean isOneTime() {
        return oneTime;
    }

    public boolean isCanBecomeGiant() {
        return canBecomeGiant;
    }

    public int getNumberOfEaten() {
        return numberOfEaten;
    }

    public String getSeason() {
        return season;
    }

    public void setNumberOfEaten(int numberOfEaten) {
        this.numberOfEaten = numberOfEaten;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public void setGrowthTime(int growthTime) {
        this.growthTime = growthTime;
    }

    public void setNumberOfStage(int numberOfStage) {
        this.numberOfStage = numberOfStage;
    }

    public void setOneTime(boolean oneTime) {
        this.oneTime = oneTime;
    }
}
