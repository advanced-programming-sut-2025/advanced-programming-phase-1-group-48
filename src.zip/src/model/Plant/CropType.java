package model.Plant;

import model.items.Item;

public enum CropType {
    Dadodi(),
    Leek();



    public void interact() {

    }
}
