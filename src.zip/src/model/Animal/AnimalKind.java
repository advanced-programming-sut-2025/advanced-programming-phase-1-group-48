package model.Animal;

import java.util.HashMap;

public enum AnimalKind {
    //ect
;
    private int capacityOfHome;
    private String animalKind;
    private int priceOfBuy;
    private int priceOfSell;


    AnimalKind(int capacityOfHome, String animalKind, int priceOfBuy, int priceOfSell) {

        this.capacityOfHome = capacityOfHome;
        this.animalKind = animalKind;
        this.priceOfBuy = priceOfBuy;
        this.priceOfSell = priceOfSell;
    }

}
