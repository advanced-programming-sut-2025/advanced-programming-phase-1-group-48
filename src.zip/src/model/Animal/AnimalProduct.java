package model.Animal;

import java.util.HashMap;

public enum AnimalProduct {
    //ect
    ;
    private int productTime;
    private HashMap<String,Integer> animalProduct;
    private int productQuality;

    AnimalProduct(HashMap<String,Integer> animalProduct, int productTime, int productQuality) {
        this.animalProduct = animalProduct;
        this.productTime = productTime;
        this.productQuality = productQuality;

    }

    //TODO

}
