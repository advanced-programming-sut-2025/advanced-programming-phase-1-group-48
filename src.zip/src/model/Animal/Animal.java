package model.Animal;

public class Animal {
    private String name;
    private int friendship;
    private boolean doFeed;
    private String Foodtype;
    private AnimalProduct product;

    public void increaseFriendShip(int delta) {}
    public void increaseQualityOfProduct(int delta) {}

    public void setName(String name) {
        this.name = name;
    }

    public void setFriendship(int friendship) {
        this.friendship = friendship;
    }

    public void setProduct(AnimalProduct product) {
        this.product = product;
    }

    public void setDoFeed(boolean doFeed) {
        this.doFeed = doFeed;
    }

    public String getName() {
        return name;
    }

    public int getFriendship() {
        return friendship;
    }

    public boolean isDoFeed() {
        return doFeed;
    }

    public AnimalProduct getProduct() {
        return product;
    }

    public String getFoodtype() {
        return Foodtype;
    }
}
