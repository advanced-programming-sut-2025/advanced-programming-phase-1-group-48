package model.Animal;

public enum FishType {
    //ect
    ;
    private String name;
    private int sellPrice;
    private String season;

}
