package model.Animal;

public class Fish {

}
