package model.Animal;

public class BarnAnimal extends Animal {
}
