package model.Animal;

public class CoopAnimal extends Animal {

}
