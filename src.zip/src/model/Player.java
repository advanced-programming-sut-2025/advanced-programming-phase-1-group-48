package model;

import model.Animal.Animal;
import model.NPC.NPC;
import model.NPC.Quest;
import model.farm.Farm;
import model.game.Position;
import model.intraction.Friendship;
import model.intraction.TradeRequest;
import model.user.EnergySystem;
import model.user.SkillSet;
import model.user.User;
import model.user.inventory.Backpack;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Queue;

public class Player {
    private Position position;
    private Farm farm;
    private EnergySystem energy;
    private User user;
    private Backpack backpack;
    private ArrayList<Animal> animals;
    private ArrayList<SkillSet> skills;
    private ArrayList<Friendship> friendships;
    private ArrayList<TradeRequest> tradeRequests;
    private ArrayList<Quest> quests;
    private ArrayList<HashMap<NPC, Integer>> npcs;
    private ArrayList<HashMap<Player,Friendship>> friend;

    public Player(Position position, Farm farm, EnergySystem energy, User user,ArrayList<Animal> animals,ArrayList<SkillSet> skills,Backpack backpack, ArrayList<Friendship> friendships,ArrayList<TradeRequest> tradeRequests,ArrayList<Quest> quests,ArrayList<HashMap<NPC, Integer>> npcs,ArrayList<HashMap<Player,Friendship>> friend ) {
        this.position = position;
        this.farm = farm;
        this.energy = energy;
        this.user = user;
        this.animals = animals;
        this.skills = skills;
        this.backpack = backpack;
        this.friend = friend;
        this.quests = quests;
        this.npcs = npcs;
        this.friendships = friendships;
        this.tradeRequests = tradeRequests;
        this.quests = quests;
        this.npcs = npcs;
    }
}
