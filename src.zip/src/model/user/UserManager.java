package model.user;

import java.util.HashMap;
import java.util.Map;

public class UserManager {
    private static UserManager instance;
    private final Map<String, User> users;
    private User loggedInUser;

    private UserManager() {
        users = new HashMap<>();
    }

    public static UserManager getInstance() {
        if (instance == null)
            instance = new UserManager();
        return instance;
    }

    public boolean isUsernameTaken(String username) {
        return users.containsKey(username);
    }

    public boolean registerUser(String username,User newUser) {
        if (isUsernameTaken(username)) return false;
        users.put(username, newUser);
        return true;
    }

    public boolean loginUser(String username, String password) {
        User user = users.get(username);
        if (user == null || !user.checkPassword(password)) {
            return false;
        }
        loggedInUser = user;
        return true;
    }

    public void logout() {
        loggedInUser = null;
    }

    public User getLoggedInUser() {
        return loggedInUser;
    }

    public boolean resetPassword(String username, int questionId, String answer, String newPassword) {
        User user = users.get(username);
        if (user == null) return false;
        user.changePassword(newPassword);
        return true;
    }

    public User getUserByUsername(String username) {
        return users.get(username);
    }
}