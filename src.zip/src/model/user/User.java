package model.user;

import model.enums.BackpackType;
import model.enums.TrashCanType;
import model.user.inventory.Backpack;
import model.user.inventory.Inventory;
import model.user.inventory.TrashCan;

public class User {
    private final String username;
    private String password;
    private String nickname;
    private String email;
    private String gender;
    private int score = 0;
    private int gameCount = 0;
    private int energy;
    private Inventory inventory;
    private Wallet wallet;


    public User(String username, String password, String nickname,
                String email, String gender, int securityQuestion, String securityAnswer) {
        this.username = username;
        this.password = password;
        this.nickname = nickname;
        this.email = email;
        this.gender = gender;
        this.energy = 200;
        this.inventory = new Inventory(new Backpack(BackpackType.BASIC),new TrashCan(TrashCanType.BASIC));
        this.wallet = new Wallet();
    }

    public String getUsername() {
        return username;
    }

    public boolean checkPassword(String newPassword) {
        return newPassword.equals(password);
    }

    public void changePassword(String newPassword) {
        this.password = newPassword;
    }

    public void changeNickname(String newNick) {
        this.nickname = newNick;
    }

    public void changeEmail(String newEmail) {
        this.email = newEmail;
    }

    public String getNickname() {
        return nickname;
    }

    public String getEmail() {
        return email;
    }

    public String getGender() {
        return gender;
    }


    public int getScore() {
        return score;
    }

    public int getGameCount() {
        return gameCount;
    }

    public void increaseScore(int amount) {
        this.score += amount;
    }

    public void incrementGameCount() {
        this.gameCount++;
    }

    public Inventory getInventory() {
        return inventory;
    }

    public Wallet getWallet() {
        return wallet;
    }

    private EnergySystem energySystem = new EnergySystem();

    public void performAction(int energyCost) {
        energySystem.consume(energyCost);
        if (energySystem.isPassedOut()) {
        }

    }
}
