package model.Weather;

public class Thunderbolt {

    void strikeAt(int x, int y){}

}
