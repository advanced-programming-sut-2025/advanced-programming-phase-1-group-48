package model.Weather;


import model.enums.SeasonType;

import java.util.Random;

public class DateAndTime {
    private static DateAndTime instance;

    private int hour = 9;
    private int day = 1;
    private final int DAYS_PER_SEASON = 28;
    SeasonType currentSeason = SeasonType.Spring;

    private DateAndTime() {}

    public static DateAndTime getInstance() {
        if (instance == null) {
            instance = new DateAndTime();
        }
        return instance;
    }

    public void advanceHour(int hours) {}

    public void advanceDay(boolean applyEffects) {
        day++;
        if (day > DAYS_PER_SEASON) {
            day = 1;
            nextSeason();
        }
    }
    public void nextSeason() {
        int index = currentSeason.ordinal();
        SeasonType[] seasons = SeasonType.values();
        currentSeason = seasons[(index + 1) % seasons.length];
    }

    public SeasonType getCurrentSeason() {
        return currentSeason;
    }

}
