package model.Weather;

import model.enums.WeatherType;
import model.game.Tile;

public class Weather {
    private static Weather instance;
    private WeatherType today;
    private WeatherType tomorrow;

    private Weather() {
    }

    public static Weather getInstance() {
        if (instance == null)
            instance = new Weather();
        return instance;
    }

    public WeatherType getToday() {
        return today;
    }

    public WeatherType getTomorrow() {
        return tomorrow;
    }

    public void generateTomorrowWeather(String currentSeason) {
    }

}

