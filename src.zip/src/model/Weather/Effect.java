package model.Weather;

public class Effect {
    public static void Effect(String currentSeason) {

    }

}
