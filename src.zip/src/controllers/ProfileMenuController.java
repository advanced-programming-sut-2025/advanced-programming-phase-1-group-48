package controllers;

import model.Result;

public class ProfileMenuController {
    public static Result changePassword(){
        return new Result(true, "Change Password");
    }
    public static Result updatePassword(){
        return new Result(true, "Update Password");
    }
    public static Result changeUsername(){
        return new Result(true, "Change Username");
    }
    public static Result updateUsername(){
        return new Result(true, "Update Username");
    }
    public static Result changeEmail(){
        return new Result(true, "Change Email");
    }
    public static Result updateEmail(){
        return new Result(true, "Update Email");
    }
    public static Result changeNickname(){
        return new Result(true, "Change Nickname");
    }
    public static Result updateNickname(){
        return new Result(true, "Update Nickname");
    }
    public static Result showUserInfo(){
        return new Result(true, "Show User Info");
    }
}
