package controllers;

import models.Friendship;

import java.util.List;

public class FriendshipController {

    private Friendship friendship;

    public FriendshipController(Friendship friendship) {
        this.friendship = friendship;
    }

    public void talk(String message) {

    }

    public void gift(String item, int amount) {

    }

    public void hug() {

    }

    public void proposeMarriage() {

    }

    private boolean isPlayersNearby() {
        return true;
    }

    // Handle daily decay of xp for all friendships (could be called daily)
    public void decayFriendshipXpForAllPlayers(List<Friendship> friendships) {

    }
}
