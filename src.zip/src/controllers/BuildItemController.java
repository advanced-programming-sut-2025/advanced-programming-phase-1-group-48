package controllers;

import model.Result;
import model.user.EnergySystem;

import java.util.regex.Matcher;

public class BuildItemController {
    public Result  showItem(Matcher matcher) {return new Result(true,"finish!");}
    public Result buildItem(Matcher matcher) {return new Result(true,"finish!");}
    public Result putItem(Matcher matcher) {return new Result(true,"finish!");}
    private void AddItemToInventory(String type){}
}
