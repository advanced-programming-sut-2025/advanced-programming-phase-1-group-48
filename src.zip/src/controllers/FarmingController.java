package controllers;
import model.Result;

import java.util.regex.Matcher;

public class FarmingController {
    public void showPLantInfo(){}

    public Result Plow(Matcher matcher) {return new Result(true,"finish!");}

    public Result crowAttack(Matcher matcher) {return new Result(true,"finish!");}

    public Result plantSeed(Matcher matcher){return new Result(true,"finish!");}

    public Result fertilize(Matcher matcher){return new Result(true,"finish!");}

    public Result howmuchWater(Matcher matcher){return new Result(true,"finish!");}

    public Result harvest(Matcher matcher){return new Result(true,"finish!");}
}
