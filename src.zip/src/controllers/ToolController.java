package controllers;

import model.game.Tile;
import model.Player;
import model.user.User;

public class ToolController {
    public static void handleEquip( String toolName) {}
    public static void handleUse(Tile[][] map) {}
    public static void handleUpgrade(String toolName, boolean isAtBlacksmith) {}
    public static void showCurrentTool(Player player) {}
    public static void showAvailableTools(Player player) {}
}