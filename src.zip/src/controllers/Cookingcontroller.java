package controllers;

import model.Result;

import java.util.regex.Matcher;

public class Cookingcontroller {
    public Result showRefrigerator(Matcher matcher){return new Result(true,"finish!");}
    public Void showRrcipes(){
        return null;
    }
    public void learnNewRecipe(Matcher matcher){}
    public void cook(Matcher matcher){}
    public Void eat(Matcher matcher){return null;}
}
