package controllers;

import model.building.Buildings;
import model.Tools.Tool;
import java.util.ArrayList;
import java.util.regex.Matcher;

public class AnimalController {
    public void buyAnimal(String animalName, Matcher matcher){}
    public void effectiveWork(){}
    public void showAnimal(Matcher matcher){}
    public void moveAnimal(String animalName, Matcher matcher){}
    public void getProductCollect(){}
    public void getProduct(){}
    public void getsellPrice(){}
    public void fishing(){}
    private boolean isCapacityAvailable(ArrayList<Buildings> building){return false;}
    private boolean isFishingRoadAvailable(ArrayList<Tool> items){return false;}



}
