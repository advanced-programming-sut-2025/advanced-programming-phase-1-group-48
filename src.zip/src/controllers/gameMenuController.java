package controllers;

import model.Result;

public class gameMenuController {
    public static Result startNewGame(){
        return new Result(true, "Start New Game");
    }
    public static Result chooseGameMap(){
        return new Result(true, "Choose Game Map");
    }
    public static Result saveGameMap(){
        return new Result(true, "Save Game Map");
    }
    public static Result loadGameMap(){
        return new Result(true, "Load Game Map");
    }
    public static Result exitGame(){
        return new Result(true, "Exit Game");
    }
    public static Result createGame(){
        return new Result(true, "Create Game");
    }
    public static Result deleteGame(){
        return new Result(true, "Delete Game");
    }
    public static Result setNextPlayerTurn(){
        return new Result(true, "Setting Next Player Turn");
    }
}
