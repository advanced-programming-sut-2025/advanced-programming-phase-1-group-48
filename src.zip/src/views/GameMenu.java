package views;

import java.util.Scanner;

public class GameMenu implements AppMenu{
    public void handleInput(String command, Scanner scanner) {
    }
}
