package views;

import java.util.Scanner;

public class ProfileMenu {
    public void handleInput(String command, Scanner scanner) {

    }
}
