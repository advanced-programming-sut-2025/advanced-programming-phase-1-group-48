package views;

import java.util.Scanner;

public class TradeMenu implements AppMenu{
    @Override
    public void handleInput(String command, Scanner scanner) {

    }
}
