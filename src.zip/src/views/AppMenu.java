package views;

import java.util.Scanner;

public interface AppMenu {
    void handleInput(String command, Scanner scanner);
}
