package views;

public class AppView {
    private static AppMenu currentMenu;

    public static void setMenu(AppMenu menu) {
        currentMenu = menu;
    }
}
