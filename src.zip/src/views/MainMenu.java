package views;

import java.util.Scanner;

public class MainMenu implements AppMenu{
    public void handleInput(String command, Scanner scanner) {

    }
}
